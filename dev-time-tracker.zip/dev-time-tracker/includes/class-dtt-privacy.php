<?php
/**
 * Privacy integration: policy text, data export and erasure.
 *
 * @package DevTimeTracker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hooks the plugin into WordPress privacy tools.
 */
class DTT_Privacy {

	/**
	 * Register privacy hooks.
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'add_policy_content' ) );
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );
	}

	/**
	 * Suggest privacy policy wording for the site owner.
	 */
	public static function add_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content = '<p>' . esc_html__( 'Dev Time Tracker stores time entries in this site\'s own database. Each entry records the user who created it, a task description, a project name, start and end times, an hourly rate and whether the time is billable.', 'dev-time-tracker' ) . '</p>';

		$content .= '<p>' . esc_html__( 'If activity logging is enabled, the plugin also records which user activated or deactivated a plugin, switched themes, changed a setting or saved a post. Only the names of changed settings are stored, never their values.', 'dev-time-tracker' ) . '</p>';

		$content .= '<p>' . esc_html__( 'No data is sent to the plugin author or to any external service. If session notification emails are enabled, session summaries are emailed to the address configured in the plugin settings.', 'dev-time-tracker' ) . '</p>';

		wp_add_privacy_policy_content(
			__( 'Dev Time Tracker', 'dev-time-tracker' ),
			wp_kses_post( wpautop( $content, false ) )
		);
	}

	/**
	 * Register the personal data exporter.
	 *
	 * @param array $exporters Registered exporters.
	 * @return array
	 */
	public static function register_exporter( $exporters ) {
		$exporters['dev-time-tracker'] = array(
			'exporter_friendly_name' => __( 'Dev Time Tracker', 'dev-time-tracker' ),
			'callback'               => array( __CLASS__, 'export_user_data' ),
		);

		return $exporters;
	}

	/**
	 * Register the personal data eraser.
	 *
	 * @param array $erasers Registered erasers.
	 * @return array
	 */
	public static function register_eraser( $erasers ) {
		$erasers['dev-time-tracker'] = array(
			'eraser_friendly_name' => __( 'Dev Time Tracker', 'dev-time-tracker' ),
			'callback'             => array( __CLASS__, 'erase_user_data' ),
		);

		return $erasers;
	}

	/**
	 * Export a user's time entries.
	 *
	 * @param string $email_address User email address.
	 * @param int    $page          Page number.
	 * @return array
	 */
	public static function export_user_data( $email_address, $page = 1 ) {
		$user = get_user_by( 'email', $email_address );

		if ( ! $user ) {
			return array(
				'data' => array(),
				'done' => true,
			);
		}

		$entries = DTT_DB::get_entries(
			array(
				'user_id' => $user->ID,
				'limit'   => 5000,
			)
		);

		$export = array();

		foreach ( $entries as $entry ) {
			$export[] = array(
				'group_id'    => 'dev-time-tracker-entries',
				'group_label' => __( 'Time entries', 'dev-time-tracker' ),
				'item_id'     => 'dtt-entry-' . (int) $entry->id,
				'data'        => array(
					array(
						'name'  => __( 'Task', 'dev-time-tracker' ),
						'value' => $entry->task_title,
					),
					array(
						'name'  => __( 'Project', 'dev-time-tracker' ),
						'value' => $entry->project_name,
					),
					array(
						'name'  => __( 'Start', 'dev-time-tracker' ),
						'value' => $entry->start_time,
					),
					array(
						'name'  => __( 'End', 'dev-time-tracker' ),
						'value' => $entry->end_time ? $entry->end_time : '',
					),
					array(
						'name'  => __( 'Duration (seconds)', 'dev-time-tracker' ),
						'value' => (int) $entry->duration_seconds,
					),
					array(
						'name'  => __( 'Billable', 'dev-time-tracker' ),
						'value' => $entry->billable ? __( 'Yes', 'dev-time-tracker' ) : __( 'No', 'dev-time-tracker' ),
					),
					array(
						'name'  => __( 'Notes', 'dev-time-tracker' ),
						'value' => $entry->notes ? $entry->notes : '',
					),
				),
			);
		}

		return array(
			'data' => $export,
			'done' => true,
		);
	}

	/**
	 * Erase a user's time entries and audit rows.
	 *
	 * @param string $email_address User email address.
	 * @param int    $page          Page number.
	 * @return array
	 */
	public static function erase_user_data( $email_address, $page = 1 ) {
		$user = get_user_by( 'email', $email_address );

		if ( ! $user ) {
			return array(
				'items_removed'  => false,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		}

		$removed = DTT_DB::delete_entries_for_user( $user->ID );
		DTT_Audit::delete_for_user( $user->ID );

		return array(
			'items_removed'  => (bool) $removed,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);
	}
}
