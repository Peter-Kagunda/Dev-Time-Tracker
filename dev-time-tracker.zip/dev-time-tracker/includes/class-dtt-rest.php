<?php
/**
 * REST API endpoints.
 *
 * @package DevTimeTracker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the plugin's REST routes.
 */
class DTT_REST {

	/**
	 * Route namespace.
	 *
	 * @var string
	 */
	const NAMESPACE_V1 = 'dev-time-tracker/v1';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register routes.
	 */
	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE_V1,
			'/session',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_active_session' ),
					'permission_callback' => array( __CLASS__, 'check_permission' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/session/start',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'start_session' ),
					'permission_callback' => array( __CLASS__, 'check_permission' ),
					'args'                => array(
						'taskTitle' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'projectId' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_key',
						),
						'billable'  => array(
							'type'     => 'boolean',
							'required' => false,
							'default'  => true,
						),
						'tags'      => array(
							'type'     => 'array',
							'required' => false,
							'items'    => array( 'type' => 'string' ),
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/session/stop',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'stop_session' ),
					'permission_callback' => array( __CLASS__, 'check_permission' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/entries',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_entries' ),
					'permission_callback' => array( __CLASS__, 'check_permission' ),
					'args'                => array(
						'limit' => array(
							'type'              => 'integer',
							'required'          => false,
							'default'           => 100,
							'minimum'           => 1,
							'maximum'           => 500,
							'sanitize_callback' => 'absint',
						),
					),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_entry' ),
					'permission_callback' => array( __CLASS__, 'check_permission' ),
					'args'                => array(
						'taskTitle'       => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'projectId'       => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_key',
						),
						'durationSeconds' => array(
							'type'              => 'integer',
							'required'          => true,
							'minimum'           => 1,
							'maximum'           => 86400,
							'sanitize_callback' => 'absint',
						),
						'hourlyRate'      => array(
							'type'     => 'number',
							'required' => false,
							'minimum'  => 0,
						),
						'billable'        => array(
							'type'     => 'boolean',
							'required' => false,
							'default'  => true,
						),
						'notes'           => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_textarea_field',
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/audit',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_audit_logs' ),
					'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
					'args'                => array(
						'limit' => array(
							'type'              => 'integer',
							'required'          => false,
							'default'           => 100,
							'minimum'           => 1,
							'maximum'           => 500,
							'sanitize_callback' => 'absint',
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/settings',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_settings' ),
					'permission_callback' => array( __CLASS__, 'check_permission' ),
				),
			)
		);
	}

	/**
	 * Permission check for tracking your own time.
	 *
	 * @return bool|WP_Error
	 */
	public static function check_permission() {
		if ( current_user_can( 'edit_posts' ) ) {
			return true;
		}

		return new WP_Error(
			'dtt_forbidden',
			__( 'You are not allowed to use the time tracker.', 'dev-time-tracker' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * Permission check for site-wide data.
	 *
	 * @return bool|WP_Error
	 */
	public static function check_admin_permission() {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		return new WP_Error(
			'dtt_forbidden',
			__( 'You are not allowed to view the activity log.', 'dev-time-tracker' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * Reduce an entry row to the fields safe to return.
	 *
	 * @param object $entry Entry row.
	 * @return array
	 */
	private static function prepare_entry( $entry ) {
		return array(
			'id'              => (int) $entry->id,
			'userId'          => (int) $entry->user_id,
			'displayName'     => isset( $entry->display_name ) ? $entry->display_name : '',
			'projectId'       => $entry->project_id,
			'projectName'     => $entry->project_name,
			'projectColor'    => $entry->project_color,
			'taskTitle'       => $entry->task_title,
			'tags'            => '' === $entry->tags ? array() : explode( ',', $entry->tags ),
			'startTime'       => $entry->start_time,
			'endTime'         => $entry->end_time,
			'durationSeconds' => (int) $entry->duration_seconds,
			'billable'        => (bool) $entry->billable,
			'hourlyRate'      => (float) $entry->hourly_rate,
			'notes'           => $entry->notes,
		);
	}

	/**
	 * Return the caller's running session.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public static function get_active_session( $request ) {
		$session = DTT_DB::get_active_session( get_current_user_id() );

		if ( ! $session ) {
			return rest_ensure_response( array( 'active' => false ) );
		}

		return rest_ensure_response(
			array(
				'active'         => true,
				'session'        => self::prepare_entry( $session ),
				'elapsedSeconds' => max( 0, time() - DTT_DB::mysql_to_timestamp( $session->start_time ) ),
			)
		);
	}

	/**
	 * Start a session for the caller.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function start_session( $request ) {
		$user_id = get_current_user_id();

		if ( DTT_DB::get_active_session( $user_id ) ) {
			return new WP_Error(
				'dtt_already_tracking',
				__( 'A session is already running.', 'dev-time-tracker' ),
				array( 'status' => 409 )
			);
		}

		$task_title = (string) $request->get_param( 'taskTitle' );

		if ( '' === $task_title ) {
			if ( get_option( 'dtt_require_task', 1 ) ) {
				return new WP_Error(
					'dtt_task_required',
					__( 'A task description is required.', 'dev-time-tracker' ),
					array( 'status' => 400 )
				);
			}

			$task_title = __( 'Untitled task', 'dev-time-tracker' );
		}

		$project  = DTT_Projects::get( (string) $request->get_param( 'projectId' ) );
		$tags     = $request->get_param( 'tags' );
		$tags     = is_array( $tags ) ? DTT_Projects::sanitize_tag_list( implode( ',', $tags ) ) : '';
		$billable = null === $request->get_param( 'billable' )
			? (int) get_option( 'dtt_default_billable', 1 )
			: (int) (bool) $request->get_param( 'billable' );

		$id = DTT_DB::insert_entry(
			array(
				'user_id'          => $user_id,
				'project_id'       => $project['id'],
				'project_name'     => $project['name'],
				'project_color'    => $project['color'],
				'task_title'       => $task_title,
				'tags'             => $tags,
				'start_time'       => current_time( 'mysql' ),
				'end_time'         => null,
				'duration_seconds' => 0,
				'billable'         => $billable,
				'hourly_rate'      => $project['rate'],
				'site_area'        => '',
			)
		);

		if ( ! $id ) {
			return new WP_Error(
				'dtt_insert_failed',
				__( 'The session could not be saved.', 'dev-time-tracker' ),
				array( 'status' => 500 )
			);
		}

		DTT_Audit::log_event(
			'timer_start',
			$project['name'],
			/* translators: %s: task description. */
			sprintf( __( 'Session started: %s', 'dev-time-tracker' ), $task_title )
		);

		return rest_ensure_response(
			array(
				'success' => true,
				'id'      => $id,
			)
		);
	}

	/**
	 * Stop the caller's running session.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function stop_session( $request ) {
		$session = DTT_DB::get_active_session( get_current_user_id() );

		if ( ! $session ) {
			return new WP_Error(
				'dtt_not_tracking',
				__( 'No session is running.', 'dev-time-tracker' ),
				array( 'status' => 409 )
			);
		}

		$now      = current_time( 'mysql' );
		$duration = max( 1, strtotime( $now ) - strtotime( $session->start_time ) );

		DTT_DB::update_entry(
			$session->id,
			array(
				'end_time'         => $now,
				'duration_seconds' => $duration,
			)
		);

		DTT_Audit::log_event(
			'timer_stop',
			$session->project_name,
			/* translators: %s: task description. */
			sprintf( __( 'Session ended: %s', 'dev-time-tracker' ), $session->task_title )
		);

		return rest_ensure_response(
			array(
				'success'  => true,
				'duration' => $duration,
			)
		);
	}

	/**
	 * List entries. Users without manage_options see only their own.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public static function get_entries( $request ) {
		$scope_user = current_user_can( 'manage_options' ) ? 0 : get_current_user_id();

		$entries = DTT_DB::get_entries(
			array(
				'user_id' => $scope_user,
				'limit'   => (int) $request->get_param( 'limit' ),
			)
		);

		return rest_ensure_response( array_map( array( __CLASS__, 'prepare_entry' ), $entries ) );
	}

	/**
	 * Create a completed entry for the caller.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_entry( $request ) {
		$task_title = (string) $request->get_param( 'taskTitle' );

		if ( '' === $task_title ) {
			$task_title = __( 'Untitled task', 'dev-time-tracker' );
		}

		$project = DTT_Projects::get( (string) $request->get_param( 'projectId' ) );
		$rate    = $request->get_param( 'hourlyRate' );
		$rate    = null === $rate ? (float) $project['rate'] : max( 0, (float) $rate );
		$now     = current_time( 'mysql' );

		$billable = null === $request->get_param( 'billable' )
			? (int) get_option( 'dtt_default_billable', 1 )
			: (int) (bool) $request->get_param( 'billable' );

		$id = DTT_DB::insert_entry(
			array(
				'user_id'          => get_current_user_id(),
				'project_id'       => $project['id'],
				'project_name'     => $project['name'],
				'project_color'    => $project['color'],
				'task_title'       => $task_title,
				'tags'             => '',
				'start_time'       => $now,
				'end_time'         => $now,
				'duration_seconds' => (int) $request->get_param( 'durationSeconds' ),
				'billable'         => $billable,
				'hourly_rate'      => $rate,
				'notes'            => (string) $request->get_param( 'notes' ),
				'site_area'        => '',
			)
		);

		if ( ! $id ) {
			return new WP_Error(
				'dtt_insert_failed',
				__( 'The entry could not be saved.', 'dev-time-tracker' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response(
			array(
				'success' => true,
				'id'      => $id,
			)
		);
	}

	/**
	 * List recent audit events.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public static function get_audit_logs( $request ) {
		$logs = DTT_Audit::get_recent_logs( (int) $request->get_param( 'limit' ) );

		$prepared = array();

		foreach ( $logs as $log ) {
			$prepared[] = array(
				'id'      => (int) $log->id,
				'userId'  => (int) $log->user_id,
				'user'    => isset( $log->developer_name ) ? $log->developer_name : '',
				'action'  => $log->action,
				'target'  => $log->target,
				'summary' => $log->summary,
				'details' => $log->details,
				'time'    => $log->time,
			);
		}

		return rest_ensure_response( $prepared );
	}

	/**
	 * Return the non-sensitive plugin settings.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public static function get_settings( $request ) {
		$settings = array(
			'autoPromptOnLogin'      => (bool) get_option( 'dtt_auto_prompt', 0 ),
			'idleDetectionMinutes'   => (int) get_option( 'dtt_idle_minutes', 10 ),
			'requireTaskDescription' => (bool) get_option( 'dtt_require_task', 1 ),
			'defaultHourlyRate'      => (float) get_option( 'dtt_default_rate', 0 ),
			'currency'               => (string) get_option( 'dtt_currency', '$' ),
			'defaultBillable'        => (bool) get_option( 'dtt_default_billable', 1 ),
			'activityLogEnabled'     => (bool) get_option( 'dtt_audit_enabled', 0 ),
			'projects'               => DTT_Projects::all(),
		);

		// The notification recipient is only exposed to administrators.
		if ( current_user_can( 'manage_options' ) ) {
			$settings['notifyOnSessionEnd'] = (bool) get_option( 'dtt_notify_logout', 0 );
			$settings['notificationEmail']  = (string) get_option( 'dtt_notify_email', '' );
		}

		return rest_ensure_response( $settings );
	}
}
