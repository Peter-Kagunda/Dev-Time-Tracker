<?php
/**
 * User-defined projects used to group time entries.
 *
 * @package DevTimeTracker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and validates the site's project list.
 */
class DTT_Projects {

	/**
	 * Option holding the project list.
	 *
	 * @var string
	 */
	const OPTION = 'dtt_projects';

	/**
	 * Maximum number of projects that can be stored.
	 *
	 * @var int
	 */
	const MAX_PROJECTS = 50;

	/**
	 * Retrieve all stored projects.
	 *
	 * @return array
	 */
	public static function all() {
		$projects = get_option( self::OPTION, array() );

		if ( ! is_array( $projects ) || empty( $projects ) ) {
			return array( self::fallback() );
		}

		$clean = array();

		foreach ( $projects as $project ) {
			if ( ! is_array( $project ) || empty( $project['id'] ) ) {
				continue;
			}

			$clean[] = self::normalize( $project );
		}

		return empty( $clean ) ? array( self::fallback() ) : $clean;
	}

	/**
	 * Retrieve one project by ID, falling back to the first available one.
	 *
	 * @param string $project_id Project ID.
	 * @return array
	 */
	public static function get( $project_id ) {
		$project_id = sanitize_key( $project_id );
		$projects   = self::all();

		foreach ( $projects as $project ) {
			if ( $project['id'] === $project_id ) {
				return self::with_rate_fallback( $project );
			}
		}

		return self::with_rate_fallback( reset( $projects ) );
	}

	/**
	 * Apply the site default rate to a project that has none of its own.
	 *
	 * @param array $project Project data.
	 * @return array
	 */
	private static function with_rate_fallback( array $project ) {
		if ( empty( $project['rate'] ) ) {
			$project['rate'] = (float) get_option( 'dtt_default_rate', 0 );
		}

		return $project;
	}

	/**
	 * A safe placeholder used when no projects exist.
	 *
	 * @return array
	 */
	private static function fallback() {
		return array(
			'id'     => 'general',
			'name'   => __( 'General development', 'dev-time-tracker' ),
			'color'  => '#2271b1',
			'client' => '',
			'rate'   => (float) get_option( 'dtt_default_rate', 0 ),
		);
	}

	/**
	 * Coerce a stored project into a known shape.
	 *
	 * @param array $project Raw project data.
	 * @return array
	 */
	private static function normalize( array $project ) {
		$color = isset( $project['color'] ) ? sanitize_hex_color( $project['color'] ) : '';

		return array(
			'id'     => sanitize_key( isset( $project['id'] ) ? $project['id'] : '' ),
			'name'   => sanitize_text_field( isset( $project['name'] ) ? $project['name'] : '' ),
			'color'  => $color ? $color : '#2271b1',
			'client' => sanitize_text_field( isset( $project['client'] ) ? $project['client'] : '' ),
			'rate'   => isset( $project['rate'] ) ? max( 0, (float) $project['rate'] ) : 0.0,
		);
	}

	/**
	 * Persist the project list submitted from the settings screen.
	 *
	 * Values are expected to be unslashed already; each field is sanitized here.
	 *
	 * @param array $submitted   Existing rows keyed by project ID.
	 * @param array $new_project Optional new row to append.
	 */
	public static function save_from_request( array $submitted, array $new_project = array() ) {
		$projects = array();
		$used_ids = array();

		foreach ( $submitted as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			if ( ! empty( $row['remove'] ) ) {
				continue;
			}

			$name = isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '';

			if ( '' === $name ) {
				continue;
			}

			$id = sanitize_key( isset( $row['id'] ) ? $row['id'] : '' );

			if ( '' === $id ) {
				$id = self::generate_id( $name, $used_ids );
			}

			if ( in_array( $id, $used_ids, true ) ) {
				continue;
			}

			$used_ids[] = $id;

			$projects[] = self::normalize(
				array(
					'id'     => $id,
					'name'   => $name,
					'color'  => isset( $row['color'] ) ? $row['color'] : '',
					'client' => isset( $row['client'] ) ? $row['client'] : '',
					'rate'   => isset( $row['rate'] ) ? $row['rate'] : 0,
				)
			);

			if ( count( $projects ) >= self::MAX_PROJECTS ) {
				break;
			}
		}

		$new_name = isset( $new_project['name'] ) ? sanitize_text_field( $new_project['name'] ) : '';

		if ( '' !== $new_name && count( $projects ) < self::MAX_PROJECTS ) {
			$projects[] = self::normalize(
				array(
					'id'     => self::generate_id( $new_name, $used_ids ),
					'name'   => $new_name,
					'color'  => isset( $new_project['color'] ) ? $new_project['color'] : '',
					'client' => isset( $new_project['client'] ) ? $new_project['client'] : '',
					'rate'   => isset( $new_project['rate'] ) ? $new_project['rate'] : 0,
				)
			);
		}

		if ( empty( $projects ) ) {
			$projects[] = self::fallback();
		}

		update_option( self::OPTION, $projects );
	}

	/**
	 * Build a unique slug for a project name.
	 *
	 * @param string $name     Project name.
	 * @param array  $used_ids IDs already taken.
	 * @return string
	 */
	private static function generate_id( $name, array $used_ids ) {
		$base = sanitize_key( sanitize_title( $name ) );

		if ( '' === $base ) {
			$base = 'project';
		}

		$base = substr( $base, 0, 40 );
		$id   = $base;
		$i    = 2;

		while ( in_array( $id, $used_ids, true ) ) {
			$id = $base . '-' . $i;
			++$i;
		}

		return $id;
	}

	/**
	 * Clean a comma separated tag string.
	 *
	 * @param string $tags Raw tag list.
	 * @return string
	 */
	public static function sanitize_tag_list( $tags ) {
		if ( ! is_string( $tags ) || '' === $tags ) {
			return '';
		}

		$parts = array_filter(
			array_map(
				static function ( $tag ) {
					return sanitize_text_field( trim( $tag ) );
				},
				explode( ',', $tags )
			)
		);

		$parts = array_slice( array_unique( $parts ), 0, 10 );

		return implode( ',', $parts );
	}
}
