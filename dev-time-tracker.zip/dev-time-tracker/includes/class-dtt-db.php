<?php
/**
 * Database layer for Dev Time Tracker.
 *
 * @package DevTimeTracker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates and queries the plugin's custom tables.
 */
class DTT_DB {

	/**
	 * Schema version stored in the options table.
	 *
	 * @var string
	 */
	const DB_VERSION = '2';

	/**
	 * Object cache group.
	 *
	 * @var string
	 */
	const CACHE_GROUP = 'dev_time_tracker';

	/**
	 * Time entries table name.
	 *
	 * @return string
	 */
	public static function get_table_entries() {
		global $wpdb;
		return $wpdb->prefix . 'dtt_entries';
	}

	/**
	 * Audit log table name.
	 *
	 * @return string
	 */
	public static function get_table_audit() {
		global $wpdb;
		return $wpdb->prefix . 'dtt_audit';
	}

	/**
	 * Convert a local MySQL datetime into a Unix timestamp.
	 *
	 * Rows store site-local time, so a plain strtotime() call would be wrong
	 * on any site that is not running in UTC.
	 *
	 * @param string $mysql_datetime Datetime in 'Y-m-d H:i:s' site-local form.
	 * @return int
	 */
	public static function mysql_to_timestamp( $mysql_datetime ) {
		if ( empty( $mysql_datetime ) ) {
			return 0;
		}

		return (int) strtotime( get_gmt_from_date( $mysql_datetime ) . ' +0000' );
	}

	/**
	 * Create tables and seed default options on activation.
	 */
	public static function install_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$table_entries   = self::get_table_entries();
		$table_audit     = self::get_table_audit();

		$sql_entries = "CREATE TABLE {$table_entries} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			project_id varchar(50) NOT NULL DEFAULT '',
			project_name varchar(100) NOT NULL DEFAULT '',
			project_color varchar(20) NOT NULL DEFAULT '#2271b1',
			task_title text NOT NULL,
			tags varchar(255) NOT NULL DEFAULT '',
			start_time datetime NOT NULL,
			end_time datetime DEFAULT NULL,
			duration_seconds int(11) NOT NULL DEFAULT 0,
			billable tinyint(1) NOT NULL DEFAULT 1,
			hourly_rate decimal(10,2) NOT NULL DEFAULT 0.00,
			notes text DEFAULT NULL,
			site_area varchar(100) NOT NULL DEFAULT '',
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY project_id (project_id),
			KEY start_time (start_time)
		) {$charset_collate};";

		$sql_audit = "CREATE TABLE {$table_audit} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			action varchar(50) NOT NULL,
			target varchar(255) NOT NULL,
			summary text NOT NULL,
			details text DEFAULT NULL,
			time datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY action (action),
			KEY user_id (user_id),
			KEY time (time)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		dbDelta( $sql_entries );
		dbDelta( $sql_audit );

		update_option( 'dtt_db_version', self::DB_VERSION );

		self::seed_default_options();
		self::flush_cache();
	}

	/**
	 * Run schema updates when the stored version is behind.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'dtt_db_version' ) === self::DB_VERSION ) {
			return;
		}

		self::install_tables();
	}

	/**
	 * Add option defaults without overwriting existing choices.
	 *
	 * Notifications, activity logging and the login prompt all default to
	 * off so nothing happens until the site owner opts in.
	 */
	private static function seed_default_options() {
		$defaults = array(
			'dtt_default_rate'         => 0,
			'dtt_currency'             => '$',
			'dtt_default_billable'     => 1,
			'dtt_auto_prompt'          => 0,
			'dtt_idle_minutes'         => 10,
			'dtt_require_task'         => 1,
			'dtt_notify_email'         => '',
			'dtt_notify_logout'        => 0,
			'dtt_audit_enabled'        => 0,
			'dtt_audit_retention_days' => 90,
		);

		foreach ( $defaults as $option => $value ) {
			if ( false === get_option( $option, false ) ) {
				add_option( $option, $value );
			}
		}
	}

	/**
	 * Clear scheduled work on deactivation. Data is kept until uninstall.
	 */
	public static function handle_deactivation() {
		$timestamp = wp_next_scheduled( 'dtt_prune_audit_log' );

		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'dtt_prune_audit_log' );
		}

		self::flush_cache();
	}

	/**
	 * Current cache generation, bumped whenever data changes.
	 *
	 * @return int
	 */
	private static function cache_version() {
		$version = wp_cache_get( 'cache_version', self::CACHE_GROUP );

		if ( false === $version ) {
			$version = 1;
			wp_cache_set( 'cache_version', $version, self::CACHE_GROUP );
		}

		return (int) $version;
	}

	/**
	 * Invalidate every cached query for this plugin.
	 */
	public static function flush_cache() {
		wp_cache_set( 'cache_version', self::cache_version() + 1, self::CACHE_GROUP );
	}

	/**
	 * Read a cached query result.
	 *
	 * @param string $key Cache key.
	 * @return mixed False when not cached.
	 */
	private static function cache_get( $key ) {
		return wp_cache_get( self::cache_version() . ':' . $key, self::CACHE_GROUP );
	}

	/**
	 * Store a query result in the object cache.
	 *
	 * @param string $key   Cache key.
	 * @param mixed  $value Value to store.
	 * @return mixed The stored value.
	 */
	private static function cache_set( $key, $value ) {
		wp_cache_set( self::cache_version() . ':' . $key, $value, self::CACHE_GROUP, 5 * MINUTE_IN_SECONDS );
		return $value;
	}

	/**
	 * Fetch a single entry by ID.
	 *
	 * @param int $id Entry ID.
	 * @return object|null
	 */
	public static function get_entry( $id ) {
		global $wpdb;

		$id = absint( $id );

		if ( $id < 1 ) {
			return null;
		}

		$cache_key = 'entry:' . $id;
		$cached    = self::cache_get( $cache_key );

		if ( false !== $cached ) {
			return $cached;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; result is cached below.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE id = %d',
				self::get_table_entries(),
				$id
			)
		);

		return self::cache_set( $cache_key, $row );
	}

	/**
	 * Fetch the running session for a user, if any.
	 *
	 * @param int $user_id User ID.
	 * @return object|null
	 */
	public static function get_active_session( $user_id ) {
		global $wpdb;

		$user_id = absint( $user_id );

		if ( $user_id < 1 ) {
			return null;
		}

		$cache_key = 'active:' . $user_id;
		$cached    = self::cache_get( $cache_key );

		if ( false !== $cached ) {
			return $cached;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; result is cached below.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE user_id = %d AND end_time IS NULL ORDER BY id DESC LIMIT 1',
				self::get_table_entries(),
				$user_id
			)
		);

		return self::cache_set( $cache_key, $row );
	}

	/**
	 * Count users with a session currently running.
	 *
	 * @return int
	 */
	public static function count_active_sessions() {
		global $wpdb;

		$cached = self::cache_get( 'active_count' );

		if ( false !== $cached ) {
			return (int) $cached;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; result is cached below.
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(DISTINCT user_id) FROM %i WHERE end_time IS NULL',
				self::get_table_entries()
			)
		);

		return (int) self::cache_set( 'active_count', $count );
	}

	/**
	 * Fetch time entries, newest first.
	 *
	 * @param array $args {
	 *     Query arguments.
	 *
	 *     @type int $user_id Restrict to one user. 0 for all users.
	 *     @type int $limit   Maximum rows to return.
	 * }
	 * @return array
	 */
	public static function get_entries( $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'user_id' => 0,
				'limit'   => 100,
			)
		);

		$user_id = absint( $args['user_id'] );
		$limit   = min( 5000, max( 1, absint( $args['limit'] ) ) );

		// Deliberately not cached -- this is the Timesheets table's source of
		// truth, and the Reports/billing summary must always match it exactly.
		if ( $user_id > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; always read live so figures can't go stale.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					'SELECT e.*, u.display_name FROM %i e LEFT JOIN %i u ON e.user_id = u.ID WHERE e.user_id = %d ORDER BY e.start_time DESC, e.id DESC LIMIT %d',
					self::get_table_entries(),
					$wpdb->users,
					$user_id,
					$limit
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; always read live so figures can't go stale.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					'SELECT e.*, u.display_name FROM %i e LEFT JOIN %i u ON e.user_id = u.ID ORDER BY e.start_time DESC, e.id DESC LIMIT %d',
					self::get_table_entries(),
					$wpdb->users,
					$limit
				)
			);
		}

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Total seconds tracked today.
	 *
	 * @param int $user_id User ID, or 0 for all users.
	 * @return int
	 */
	public static function get_today_seconds( $user_id = 0 ) {
		global $wpdb;

		$user_id = absint( $user_id );
		$today   = current_time( 'Y-m-d' );

		$cache_key = 'today_seconds:' . $user_id . ':' . $today;
		$cached    = self::cache_get( $cache_key );

		if ( false !== $cached ) {
			return (int) $cached;
		}

		if ( $user_id > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; result is cached below.
			$total = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT SUM(duration_seconds) FROM %i WHERE user_id = %d AND DATE(start_time) = %s',
					self::get_table_entries(),
					$user_id,
					$today
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; result is cached below.
			$total = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT SUM(duration_seconds) FROM %i WHERE DATE(start_time) = %s',
					self::get_table_entries(),
					$today
				)
			);
		}

		return (int) self::cache_set( $cache_key, (int) $total );
	}

	/**
	 * Billable value of today's entries.
	 *
	 * @param int $user_id User ID, or 0 for all users.
	 * @return float
	 */
	public static function get_today_billable( $user_id = 0 ) {
		global $wpdb;

		$user_id = absint( $user_id );
		$today   = current_time( 'Y-m-d' );

		$cache_key = 'today_billable:' . $user_id . ':' . $today;
		$cached    = self::cache_get( $cache_key );

		if ( false !== $cached ) {
			return (float) $cached;
		}

		if ( $user_id > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; result is cached below.
			$total = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT SUM( ( duration_seconds * hourly_rate / 3600.0 ) ) FROM %i WHERE user_id = %d AND billable = 1 AND DATE(start_time) = %s',
					self::get_table_entries(),
					$user_id,
					$today
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; result is cached below.
			$total = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT SUM( ( duration_seconds * hourly_rate / 3600.0 ) ) FROM %i WHERE billable = 1 AND DATE(start_time) = %s',
					self::get_table_entries(),
					$today
				)
			);
		}

		return (float) self::cache_set( $cache_key, (float) $total );
	}

	/**
	 * Totals grouped by project.
	 *
	 * Deliberately NOT cached: this powers the Reports KPI cards and the
	 * printable billing summary, both of which must always match the
	 * Timesheets table (which always queries live). Caching this for even
	 * a few minutes lets the invoice show stale amounts right after a
	 * session ends or an entry is added/edited/deleted -- exactly the kind
	 * of mismatch that must never happen on a billing document.
	 *
	 * @param int $user_id User ID, or 0 for all users.
	 * @return array
	 */
	public static function get_project_summary( $user_id = 0 ) {
		global $wpdb;

		$user_id = absint( $user_id );

		if ( $user_id > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; always read live so billing figures can't go stale.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					'SELECT project_id, project_name, project_color, SUM(duration_seconds) AS total_seconds, SUM( CASE WHEN billable = 1 THEN ( duration_seconds * hourly_rate / 3600.0 ) ELSE 0 END ) AS total_billable FROM %i WHERE user_id = %d GROUP BY project_id, project_name, project_color ORDER BY total_seconds DESC',
					self::get_table_entries(),
					$user_id
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; always read live so billing figures can't go stale.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					'SELECT project_id, project_name, project_color, SUM(duration_seconds) AS total_seconds, SUM( CASE WHEN billable = 1 THEN ( duration_seconds * hourly_rate / 3600.0 ) ELSE 0 END ) AS total_billable FROM %i GROUP BY project_id, project_name, project_color ORDER BY total_seconds DESC',
					self::get_table_entries()
				)
			);
		}

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Insert a time entry.
	 *
	 * @param array $data Column values.
	 * @return int Inserted row ID, or 0 on failure.
	 */
	public static function insert_entry( $data ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom table with no core API.
		$result = $wpdb->insert( self::get_table_entries(), $data );

		self::flush_cache();

		return $result ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Update a time entry.
	 *
	 * @param int   $id   Entry ID.
	 * @param array $data Column values.
	 * @return int|false Rows affected, or false on error.
	 */
	public static function update_entry( $id, $data ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; caches are flushed below.
		$result = $wpdb->update( self::get_table_entries(), $data, array( 'id' => absint( $id ) ) );

		self::flush_cache();

		return $result;
	}

	/**
	 * Delete a time entry.
	 *
	 * @param int $id Entry ID.
	 * @return int|false Rows affected, or false on error.
	 */
	public static function delete_entry( $id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; caches are flushed below.
		$result = $wpdb->delete( self::get_table_entries(), array( 'id' => absint( $id ) ) );

		self::flush_cache();

		return $result;
	}

	/**
	 * Delete every entry belonging to a user.
	 *
	 * @param int $user_id User ID.
	 * @return int|false Rows affected, or false on error.
	 */
	public static function delete_entries_for_user( $user_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; caches are flushed below.
		$result = $wpdb->delete( self::get_table_entries(), array( 'user_id' => absint( $user_id ) ) );

		self::flush_cache();

		return $result;
	}
}
