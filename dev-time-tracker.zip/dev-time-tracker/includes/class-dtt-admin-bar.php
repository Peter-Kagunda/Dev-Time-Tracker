<?php
/**
 * Admin bar timer node.
 *
 * @package DevTimeTracker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds a live timer to the admin bar.
 */
class DTT_Admin_Bar {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_bar_menu', array( __CLASS__, 'add_admin_bar_items' ), 100 );
	}

	/**
	 * Add the timer node.
	 *
	 * @param WP_Admin_Bar $admin_bar Admin bar instance.
	 */
	public static function add_admin_bar_items( $admin_bar ) {
		if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		if ( ! $admin_bar instanceof WP_Admin_Bar ) {
			return;
		}

		$session = DTT_DB::get_active_session( get_current_user_id() );
		$href    = admin_url( 'admin.php?page=dev-time-tracker' );

		if ( ! $session ) {
			$admin_bar->add_node(
				array(
					'id'    => 'dtt_live_tracker',
					'title' => '<span class="ab-icon dashicons dashicons-clock" aria-hidden="true"></span><span class="ab-label">'
						. esc_html__( 'Track time', 'dev-time-tracker' ) . '</span>',
					'href'  => $href,
					'meta'  => array( 'class' => 'dtt-admin-bar-idle' ),
				)
			);

			return;
		}

		$start_ts = DTT_DB::mysql_to_timestamp( $session->start_time );
		$elapsed  = max( 0, time() - $start_ts );

		$time_str = sprintf(
			'%02d:%02d:%02d',
			(int) floor( $elapsed / HOUR_IN_SECONDS ),
			(int) floor( ( $elapsed % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS ),
			(int) ( $elapsed % MINUTE_IN_SECONDS )
		);

		$title = '<span class="dtt-ab-pulse" aria-hidden="true"></span>'
			. '<span class="dtt-ab-timer" data-start="' . esc_attr( $start_ts ) . '">' . esc_html( $time_str ) . '</span>'
			. '<span class="dtt-ab-proj">' . esc_html( $session->project_name ) . '</span>';

		$admin_bar->add_node(
			array(
				'id'    => 'dtt_live_tracker',
				'title' => $title,
				'href'  => $href,
				'meta'  => array(
					'class' => 'dtt-admin-bar-active',
					'title' => __( 'Time tracking in progress', 'dev-time-tracker' ),
				),
			)
		);
	}
}
