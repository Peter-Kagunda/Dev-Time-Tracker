<?php
/**
 * Activity audit log.
 *
 * Logging is opt-in. When enabled, only actions taken by logged-in users who
 * can edit content are recorded, and only the names of changed settings are
 * stored, never their values.
 *
 * @package DevTimeTracker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records and reads plugin audit events.
 */
class DTT_Audit {

	/**
	 * Attach hooks once, only when logging is switched on.
	 */
	public static function init() {
		add_action( 'dtt_prune_audit_log', array( __CLASS__, 'prune' ) );

		if ( ! self::is_enabled() ) {
			return;
		}

		if ( ! wp_next_scheduled( 'dtt_prune_audit_log' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'dtt_prune_audit_log' );
		}

		add_action( 'activated_plugin', array( __CLASS__, 'on_plugin_activated' ) );
		add_action( 'deactivated_plugin', array( __CLASS__, 'on_plugin_deactivated' ) );
		add_action( 'switch_theme', array( __CLASS__, 'on_theme_switched' ) );
		add_action( 'updated_option', array( __CLASS__, 'on_option_updated' ), 10, 1 );
		add_action( 'save_post', array( __CLASS__, 'on_post_saved' ), 10, 3 );
	}

	/**
	 * Whether the site owner has enabled activity logging.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) get_option( 'dtt_audit_enabled', 0 );
	}

	/**
	 * Whether the current request should produce a log entry.
	 *
	 * @return bool
	 */
	private static function should_log() {
		if ( ! self::is_enabled() ) {
			return false;
		}

		if ( wp_doing_cron() ) {
			return false;
		}

		$user_id = get_current_user_id();

		if ( $user_id < 1 ) {
			return false;
		}

		/**
		 * Filter whether the current action is recorded in the audit log.
		 *
		 * @param bool $should_log Whether to log.
		 * @param int  $user_id    Current user ID.
		 */
		return (bool) apply_filters( 'dtt_should_log_event', current_user_can( 'edit_posts' ), $user_id );
	}

	/**
	 * Write an event to the audit log.
	 *
	 * @param string $action  Machine-readable event type.
	 * @param string $target  What the event applied to.
	 * @param string $summary Human-readable description.
	 * @param string $details Optional extra context.
	 * @return bool True when a row was written.
	 */
	public static function log_event( $action, $target, $summary, $details = '' ) {
		if ( ! self::should_log() ) {
			return false;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom table with no core API.
		$result = $wpdb->insert(
			DTT_DB::get_table_audit(),
			array(
				'user_id' => get_current_user_id(),
				'action'  => sanitize_key( $action ),
				'target'  => sanitize_text_field( mb_substr( (string) $target, 0, 255 ) ),
				'summary' => sanitize_text_field( $summary ),
				'details' => sanitize_textarea_field( $details ),
				'time'    => current_time( 'mysql' ),
			)
		);

		DTT_DB::flush_cache();

		return (bool) $result;
	}

	/**
	 * Read recent audit rows.
	 *
	 * @param int $limit Maximum rows to return.
	 * @return array
	 */
	public static function get_recent_logs( $limit = 100 ) {
		global $wpdb;

		$limit     = min( 1000, max( 1, absint( $limit ) ) );
		$cache_key = 'dtt_audit_recent_' . $limit;
		$cached    = wp_cache_get( $cache_key, DTT_DB::CACHE_GROUP );

		if ( false !== $cached ) {
			return $cached;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; result is cached below.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT a.*, u.display_name AS developer_name FROM %i a LEFT JOIN %i u ON a.user_id = u.ID ORDER BY a.time DESC, a.id DESC LIMIT %d',
				DTT_DB::get_table_audit(),
				$wpdb->users,
				$limit
			)
		);

		$rows = is_array( $rows ) ? $rows : array();

		wp_cache_set( $cache_key, $rows, DTT_DB::CACHE_GROUP, MINUTE_IN_SECONDS );

		return $rows;
	}

	/**
	 * Delete audit rows older than the configured retention window.
	 */
	public static function prune() {
		$days = (int) get_option( 'dtt_audit_retention_days', 90 );

		if ( $days < 1 ) {
			return;
		}

		global $wpdb;

		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; scheduled cleanup task.
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE time < %s',
				DTT_DB::get_table_audit(),
				$cutoff
			)
		);

		DTT_DB::flush_cache();
	}

	/**
	 * Delete every audit row belonging to a user.
	 *
	 * @param int $user_id User ID.
	 */
	public static function delete_for_user( $user_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table with no core API; caches are flushed below.
		$wpdb->delete( DTT_DB::get_table_audit(), array( 'user_id' => absint( $user_id ) ) );

		DTT_DB::flush_cache();
	}

	/**
	 * Log a plugin activation.
	 *
	 * @param string $plugin Plugin file.
	 */
	public static function on_plugin_activated( $plugin ) {
		self::log_event(
			'plugin_change',
			$plugin,
			/* translators: %s: plugin file path. */
			sprintf( __( 'Plugin activated: %s', 'dev-time-tracker' ), $plugin )
		);
	}

	/**
	 * Log a plugin deactivation.
	 *
	 * @param string $plugin Plugin file.
	 */
	public static function on_plugin_deactivated( $plugin ) {
		self::log_event(
			'plugin_change',
			$plugin,
			/* translators: %s: plugin file path. */
			sprintf( __( 'Plugin deactivated: %s', 'dev-time-tracker' ), $plugin )
		);
	}

	/**
	 * Log a theme switch.
	 *
	 * @param string $new_name Theme name.
	 */
	public static function on_theme_switched( $new_name ) {
		self::log_event(
			'theme_update',
			$new_name,
			/* translators: %s: theme name. */
			sprintf( __( 'Active theme changed to: %s', 'dev-time-tracker' ), $new_name )
		);
	}

	/**
	 * Log a settings change. Only the option name is stored.
	 *
	 * @param string $option Option name.
	 */
	public static function on_option_updated( $option ) {
		if ( ! self::is_loggable_option( $option ) ) {
			return;
		}

		self::log_event(
			'option_update',
			$option,
			/* translators: %s: option name. */
			sprintf( __( 'Setting changed: %s', 'dev-time-tracker' ), $option )
		);
	}

	/**
	 * Decide whether an option change is worth recording.
	 *
	 * Skips transients, cron, internal bookkeeping and this plugin's own
	 * options so the log stays readable and free of sensitive values.
	 *
	 * @param string $option Option name.
	 * @return bool
	 */
	private static function is_loggable_option( $option ) {
		$option = (string) $option;

		if ( '' === $option || '_' === $option[0] ) {
			return false;
		}

		$skip_prefixes = array( 'dtt_', 'transient_', 'site_transient_' );

		foreach ( $skip_prefixes as $prefix ) {
			if ( 0 === strpos( $option, $prefix ) ) {
				return false;
			}
		}

		$skip_exact = array(
			'cron',
			'recently_activated',
			'rewrite_rules',
			'db_upgraded',
			'can_compress_scripts',
			'auto_updater.lock',
			'wp_force_deactivated_plugins',
		);

		if ( in_array( $option, $skip_exact, true ) ) {
			return false;
		}

		if ( false !== strpos( $option, 'transient' ) || false !== strpos( $option, '_cache' ) ) {
			return false;
		}

		/**
		 * Filter whether a changed option is recorded.
		 *
		 * @param bool   $loggable Whether to log this option.
		 * @param string $option   Option name.
		 */
		return (bool) apply_filters( 'dtt_is_loggable_option', true, $option );
	}

	/**
	 * Log a post being created or updated.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an update.
	 */
	public static function on_post_saved( $post_id, $post, $update ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! $post instanceof WP_Post ) {
			return;
		}

		if ( in_array( $post->post_type, array( 'attachment', 'nav_menu_item', 'customize_changeset' ), true ) ) {
			return;
		}

		if ( 'auto-draft' === $post->post_status ) {
			return;
		}

		$title = get_the_title( $post_id );

		if ( '' === $title ) {
			$title = '#' . $post_id;
		}

		self::log_event(
			'post_save',
			sprintf( '%s: %s (#%d)', $post->post_type, $title, $post_id ),
			$update
				/* translators: 1: post type, 2: post title. */
				? sprintf( __( '%1$s updated: %2$s', 'dev-time-tracker' ), $post->post_type, $title )
				/* translators: 1: post type, 2: post title. */
				: sprintf( __( '%1$s created: %2$s', 'dev-time-tracker' ), $post->post_type, $title )
		);
	}
}
