<?php
/**
 * Admin screens.
 *
 * @package DevTimeTracker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the plugin's admin pages.
 */
class DTT_Admin_View {

	/**
	 * Common currency symbols offered on the settings screen.
	 *
	 * Keyed by the symbol actually stored and displayed, so choosing one
	 * from the list needs no separate code-to-symbol mapping.
	 *
	 * @return array<string, string> Symbol => descriptive label.
	 */
	public static function get_currency_options() {
		return array(
			'$'   => __( 'US Dollar ($)', 'dev-time-tracker' ),
			'€'   => __( 'Euro (€)', 'dev-time-tracker' ),
			'£'   => __( 'British Pound (£)', 'dev-time-tracker' ),
			'KSh' => __( 'Kenyan Shilling (KSh)', 'dev-time-tracker' ),
			'₦'   => __( 'Nigerian Naira (₦)', 'dev-time-tracker' ),
			'R'   => __( 'South African Rand (R)', 'dev-time-tracker' ),
			'₹'   => __( 'Indian Rupee (₹)', 'dev-time-tracker' ),
			'¥'   => __( 'Japanese Yen (¥)', 'dev-time-tracker' ),
			'A$'  => __( 'Australian Dollar (A$)', 'dev-time-tracker' ),
			'C$'  => __( 'Canadian Dollar (C$)', 'dev-time-tracker' ),
			'CHF' => __( 'Swiss Franc (CHF)', 'dev-time-tracker' ),
		);
	}

	/**
	 * Currency symbol taken from the settings.
	 *
	 * Accepts either a bare symbol or a label such as "USD ($)".
	 *
	 * @return string
	 */
	public static function get_currency_symbol() {
		$currency = (string) get_option( 'dtt_currency', '$' );

		if ( preg_match( '/\(([^)]+)\)/', $currency, $matches ) ) {
			return trim( $matches[1] );
		}

		$clean = trim( $currency );

		return '' === $clean ? '$' : $clean;
	}

	/**
	 * Format a monetary amount. Returns an unescaped string.
	 *
	 * @param float $amount Amount.
	 * @return string
	 */
	public static function format_amount( $amount ) {
		return self::get_currency_symbol() . number_format_i18n( (float) $amount, 2 );
	}

	/**
	 * Format a number of seconds as "00h 00m".
	 *
	 * @param int $seconds Seconds.
	 * @return string
	 */
	public static function format_duration( $seconds ) {
		$seconds = max( 0, (int) $seconds );

		return sprintf(
			'%02dh %02dm',
			(int) floor( $seconds / HOUR_IN_SECONDS ),
			(int) floor( ( $seconds % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS )
		);
	}

	/**
	 * Format a number of seconds as "00:00:00".
	 *
	 * @param int $seconds Seconds.
	 * @return string
	 */
	public static function format_clock( $seconds ) {
		$seconds = max( 0, (int) $seconds );

		return sprintf(
			'%02d:%02d:%02d',
			(int) floor( $seconds / HOUR_IN_SECONDS ),
			(int) floor( ( $seconds % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS ),
			(int) ( $seconds % MINUTE_IN_SECONDS )
		);
	}

	/**
	 * Format a stored datetime using the site's date and time settings.
	 *
	 * @param string $mysql_datetime Site-local datetime.
	 * @param string $format         Optional explicit format.
	 * @return string
	 */
	public static function format_datetime( $mysql_datetime, $format = '' ) {
		$timestamp = DTT_DB::mysql_to_timestamp( $mysql_datetime );

		if ( ! $timestamp ) {
			return '';
		}

		if ( '' === $format ) {
			$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		}

		return wp_date( $format, $timestamp );
	}

	/**
	 * Whether the current user may see other users' entries.
	 *
	 * @return bool
	 */
	private static function can_view_all() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * User ID to scope queries by, or 0 for all users.
	 *
	 * @return int
	 */
	private static function scope_user_id() {
		return self::can_view_all() ? 0 : get_current_user_id();
	}

	/**
	 * Output the shared page header and tab navigation.
	 *
	 * @param string $active_tab Current tab key.
	 */
	public static function render_header( $active_tab ) {
		$session     = DTT_DB::get_active_session( get_current_user_id() );
		$is_tracking = ! empty( $session );

		$tabs = array(
			'dashboard'  => array(
				'page'  => 'dev-time-tracker',
				'label' => __( 'Dashboard & Timer', 'dev-time-tracker' ),
				'cap'   => 'edit_posts',
			),
			'timesheets' => array(
				'page'  => 'dtt-timesheets',
				'label' => __( 'Timesheets', 'dev-time-tracker' ),
				'cap'   => 'edit_posts',
			),
			'audit'      => array(
				'page'  => 'dtt-audit',
				'label' => __( 'Audit Log', 'dev-time-tracker' ),
				'cap'   => 'manage_options',
			),
			'reports'    => array(
				'page'  => 'dtt-reports',
				'label' => __( 'Reports & Invoicing', 'dev-time-tracker' ),
				'cap'   => 'manage_options',
			),
			'settings'   => array(
				'page'  => 'dtt-settings',
				'label' => __( 'Settings', 'dev-time-tracker' ),
				'cap'   => 'manage_options',
			),
		);
		?>
		<div class="wrap dtt-admin-wrap">
			<div class="dtt-header-bar">
				<div class="dtt-brand">
					<span class="dashicons dashicons-clock dtt-brand-icon" aria-hidden="true"></span>
					<div>
						<h1 class="dtt-title">
							<?php echo esc_html__( 'Dev Time Tracker', 'dev-time-tracker' ); ?>
							<span class="dtt-version-badge">v<?php echo esc_html( DEVTIME_VERSION ); ?></span>
						</h1>
						<p class="dtt-subtitle">
							<?php echo esc_html__( 'Time tracking, activity log and billable summaries.', 'dev-time-tracker' ); ?>
						</p>
					</div>
				</div>
				<div class="dtt-header-status">
					<?php if ( $is_tracking ) : ?>
						<div class="dtt-status-pill tracking">
							<span class="dtt-pulse-dot" aria-hidden="true"></span>
							<span>
								<?php
								printf(
									/* translators: %s: project name. */
									esc_html__( 'Tracking: %s', 'dev-time-tracker' ),
									'<strong>' . esc_html( $session->project_name ) . '</strong>'
								);
								?>
							</span>
						</div>
					<?php else : ?>
						<div class="dtt-status-pill idle">
							<span><?php echo esc_html__( 'Not tracking', 'dev-time-tracker' ); ?></span>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<?php self::render_notices(); ?>

			<nav class="nav-tab-wrapper dtt-nav-tabs">
				<?php
				foreach ( $tabs as $key => $tab ) :
					if ( ! current_user_can( $tab['cap'] ) ) {
						continue;
					}
					?>
					<a
						href="<?php echo esc_url( admin_url( 'admin.php?page=' . $tab['page'] ) ); ?>"
						class="nav-tab <?php echo esc_attr( $active_tab === $key ? 'nav-tab-active' : '' ); ?>"
					><?php echo esc_html( $tab['label'] ); ?></a>
				<?php endforeach; ?>
			</nav>
		<?php
	}

	/**
	 * Close the wrapper opened by render_header().
	 */
	public static function render_footer() {
		echo '</div>';
	}

	/**
	 * Print admin notices for the redirect messages this plugin sets.
	 */
	public static function render_notices() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only notice rendering from a redirect this plugin performed; no state changes.
		$msg   = isset( $_GET['dtt_msg'] ) ? sanitize_key( wp_unslash( $_GET['dtt_msg'] ) ) : '';
		$error = isset( $_GET['dtt_error'] ) ? sanitize_key( wp_unslash( $_GET['dtt_error'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$messages = array(
			'settings_saved'   => __( 'Settings saved.', 'dev-time-tracker' ),
			'timer_started'    => __( 'Timer started. A live counter is now shown in the admin bar.', 'dev-time-tracker' ),
			'timer_stopped'    => __( 'Session stopped and added to your timesheet.', 'dev-time-tracker' ),
			'milestone_added'  => __( 'Note added to the running session.', 'dev-time-tracker' ),
			'entry_added'      => __( 'Timesheet entry saved.', 'dev-time-tracker' ),
			'entry_deleted'    => __( 'Timesheet entry deleted.', 'dev-time-tracker' ),
		);

		$errors = array(
			'already_tracking'  => __( 'You already have a session running. Stop it before starting another.', 'dev-time-tracker' ),
			'not_tracking'      => __( 'There is no session running.', 'dev-time-tracker' ),
			'task_required'     => __( 'Enter a task description before starting the timer.', 'dev-time-tracker' ),
			'invalid_duration'  => __( 'Enter a duration of at least one minute.', 'dev-time-tracker' ),
		);

		if ( isset( $messages[ $msg ] ) ) {
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
				esc_html( $messages[ $msg ] )
			);
		}

		if ( isset( $errors[ $error ] ) ) {
			printf(
				'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
				esc_html( $errors[ $error ] )
			);
		}
	}

	/**
	 * Dashboard and timer screen.
	 */
	public static function render_dashboard() {
		self::render_header( 'dashboard' );

		$user_id     = get_current_user_id();
		$session     = DTT_DB::get_active_session( $user_id );
		$is_tracking = ! empty( $session );
		$projects    = DTT_Projects::all();
		$scope       = self::scope_user_id();

		$today_seconds  = DTT_DB::get_today_seconds( $scope );
		$today_billable = DTT_DB::get_today_billable( $scope );
		$recent_entries = DTT_DB::get_entries(
			array(
				'user_id' => $scope,
				'limit'   => 5,
			)
		);
		$active_count   = DTT_DB::count_active_sessions();
		$default_rate   = (float) get_option( 'dtt_default_rate', 0 );
		?>
		<div class="dtt-kpi-grid">
			<div class="dtt-kpi-card">
				<div>
					<div class="dtt-kpi-label"><?php echo esc_html__( 'Tracked today', 'dev-time-tracker' ); ?></div>
					<div class="dtt-kpi-val"><?php echo esc_html( self::format_clock( $today_seconds ) ); ?></div>
				</div>
				<div class="dtt-kpi-icon-box sky">
					<span class="dashicons dashicons-clock" aria-hidden="true"></span>
				</div>
			</div>

			<div class="dtt-kpi-card">
				<div>
					<div class="dtt-kpi-label"><?php echo esc_html__( 'Billable today', 'dev-time-tracker' ); ?></div>
					<div class="dtt-kpi-val emerald"><?php echo esc_html( self::format_amount( $today_billable ) ); ?></div>
				</div>
				<div class="dtt-kpi-icon-box emerald">
					<span class="dashicons dashicons-money-alt" aria-hidden="true"></span>
				</div>
			</div>

			<div class="dtt-kpi-card">
				<div>
					<div class="dtt-kpi-label"><?php echo esc_html__( 'Sessions running', 'dev-time-tracker' ); ?></div>
					<div class="dtt-kpi-val"><?php echo esc_html( number_format_i18n( $active_count ) ); ?></div>
				</div>
				<div class="dtt-dev-avatars">
					<?php echo get_avatar( $user_id, 32 ); ?>
				</div>
			</div>
		</div>

		<div class="dtt-timer-card">
			<?php if ( $is_tracking ) : ?>
				<?php
				$start_ts = DTT_DB::mysql_to_timestamp( $session->start_time );
				$elapsed  = max( 0, time() - $start_ts );
				?>
				<div class="dtt-active-card">
					<div class="dtt-active-meta">
						<span class="dtt-pulse-dot" aria-hidden="true"></span>
						<div>
							<div class="dtt-active-project">
								<span
									class="dtt-project-dot"
									style="background:<?php echo esc_attr( $session->project_color ); ?>;"
									aria-hidden="true"
								></span>
								<span class="dtt-active-project-name"><?php echo esc_html( $session->project_name ); ?></span>
							</div>
							<div class="dtt-active-task"><?php echo esc_html( $session->task_title ); ?></div>
						</div>
					</div>

					<div class="dtt-active-controls">
						<div
							id="dtt-live-clock"
							class="dtt-clock-readout"
							data-start="<?php echo esc_attr( $start_ts ); ?>"
						><?php echo esc_html( self::format_clock( $elapsed ) ); ?></div>

						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<?php wp_nonce_field( 'dtt_stop_timer_action' ); ?>
							<input type="hidden" name="action" value="dtt_stop_timer" />
							<button type="submit" class="dtt-btn-stop">
								<?php echo esc_html__( 'Stop timer', 'dev-time-tracker' ); ?>
							</button>
						</form>
					</div>
				</div>

				<form
					method="post"
					action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					class="dtt-milestone-form"
				>
					<?php wp_nonce_field( 'dtt_add_milestone_action' ); ?>
					<input type="hidden" name="action" value="dtt_add_milestone" />
					<label class="screen-reader-text" for="dtt-milestone-note">
						<?php echo esc_html__( 'Session note', 'dev-time-tracker' ); ?>
					</label>
					<input
						type="text"
						id="dtt-milestone-note"
						name="milestone_note"
						class="regular-text"
						placeholder="<?php echo esc_attr__( 'Add a note or commit reference', 'dev-time-tracker' ); ?>"
					/>
					<button type="submit" class="button"><?php echo esc_html__( 'Add note', 'dev-time-tracker' ); ?></button>
				</form>

				<div id="dtt-idle-warning" class="notice notice-warning inline dtt-idle-warning" role="status" hidden></div>

				<?php if ( ! empty( $session->notes ) ) : ?>
					<div class="dtt-session-notes">
						<?php echo nl2br( esc_html( $session->notes ) ); ?>
					</div>
				<?php endif; ?>

			<?php else : ?>
				<form
					method="post"
					action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					id="dtt-start-form"
				>
					<?php wp_nonce_field( 'dtt_start_timer_action' ); ?>
					<input type="hidden" name="action" value="dtt_start_timer" />
					<input
						type="hidden"
						name="billable"
						id="dtt-billable-hidden"
						value="<?php echo esc_attr( get_option( 'dtt_default_billable', 1 ) ? '1' : '0' ); ?>"
					/>
					<input type="hidden" name="tags" id="dtt-tags-hidden" value="" />

					<div class="dtt-timer-row">
						<div class="dtt-input-grow">
							<label class="screen-reader-text" for="dtt-task-input">
								<?php echo esc_html__( 'Task description', 'dev-time-tracker' ); ?>
							</label>
							<input
								type="text"
								name="task_title"
								id="dtt-task-input"
								class="dtt-task-input"
								placeholder="<?php echo esc_attr__( 'What are you working on?', 'dev-time-tracker' ); ?>"
								<?php echo get_option( 'dtt_require_task', 1 ) ? 'required' : ''; ?>
							/>
						</div>

						<label class="screen-reader-text" for="dtt-project-select">
							<?php echo esc_html__( 'Project', 'dev-time-tracker' ); ?>
						</label>
						<select name="project_id" id="dtt-project-select" class="dtt-project-select">
							<?php foreach ( $projects as $project ) : ?>
								<option value="<?php echo esc_attr( $project['id'] ); ?>">
									<?php echo esc_html( $project['name'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>

						<button
							type="button"
							class="dtt-btn-billable<?php echo get_option( 'dtt_default_billable', 1 ) ? '' : ' free'; ?>"
							id="dtt-btn-billable-toggle"
							aria-pressed="<?php echo get_option( 'dtt_default_billable', 1 ) ? 'true' : 'false'; ?>"
							data-label-billable="<?php echo esc_attr__( 'Billable', 'dev-time-tracker' ); ?>"
							data-label-free="<?php echo esc_attr__( 'Not billable', 'dev-time-tracker' ); ?>"
						>
							<span>
								<?php
								echo get_option( 'dtt_default_billable', 1 )
									? esc_html__( 'Billable', 'dev-time-tracker' )
									: esc_html__( 'Not billable', 'dev-time-tracker' );
								?>
							</span>
						</button>

						<div class="dtt-clock-readout" id="dtt-idle-clock">00:00:00</div>

						<button type="submit" class="dtt-btn-start">
							<?php echo esc_html__( 'Start timer', 'dev-time-tracker' ); ?>
						</button>
					</div>

					<?php if ( $default_rate > 0 ) : ?>
						<p class="dtt-rate-hint">
							<?php
							printf(
								/* translators: %s: formatted hourly rate. */
								esc_html__( 'Default rate: %s per hour. Project rates override this.', 'dev-time-tracker' ),
								esc_html( self::format_amount( $default_rate ) )
							);
							?>
						</p>
					<?php endif; ?>
				</form>
			<?php endif; ?>
		</div>

		<?php if ( DTT_Audit::is_enabled() ) : ?>
			<div class="dtt-audit-notice-banner">
				<span class="dashicons dashicons-shield-alt" aria-hidden="true"></span>
				<div>
					<?php echo esc_html__( 'Activity logging is on. Plugin activations, theme switches, setting names and post saves are recorded in the audit log.', 'dev-time-tracker' ); ?>
				</div>
			</div>
		<?php endif; ?>

		<div class="dtt-table-card">
			<div class="dtt-table-card-header">
				<h2><?php echo esc_html__( 'Recent sessions', 'dev-time-tracker' ); ?></h2>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=dtt-timesheets' ) ); ?>">
					<?php echo esc_html__( 'View all timesheets', 'dev-time-tracker' ); ?>
				</a>
			</div>
			<table class="dtt-table">
				<thead>
					<tr>
						<th scope="col"><?php echo esc_html__( 'User', 'dev-time-tracker' ); ?></th>
						<th scope="col"><?php echo esc_html__( 'Project', 'dev-time-tracker' ); ?></th>
						<th scope="col"><?php echo esc_html__( 'Task', 'dev-time-tracker' ); ?></th>
						<th scope="col"><?php echo esc_html__( 'Date', 'dev-time-tracker' ); ?></th>
						<th scope="col"><?php echo esc_html__( 'Duration', 'dev-time-tracker' ); ?></th>
						<th scope="col"><?php echo esc_html__( 'Rate', 'dev-time-tracker' ); ?></th>
						<th scope="col"><?php echo esc_html__( 'Total', 'dev-time-tracker' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $recent_entries ) ) : ?>
						<tr>
							<td colspan="7" class="dtt-empty">
								<?php echo esc_html__( 'No time entries yet. Start the timer above to record your first session.', 'dev-time-tracker' ); ?>
							</td>
						</tr>
					<?php else : ?>
						<?php foreach ( $recent_entries as $entry ) : ?>
							<?php
							$hours = $entry->duration_seconds / HOUR_IN_SECONDS;
							$total = $entry->billable ? $hours * (float) $entry->hourly_rate : 0;
							?>
							<tr>
								<td>
									<div class="dtt-user-cell">
										<?php echo get_avatar( $entry->user_id, 24 ); ?>
										<span><?php echo esc_html( self::entry_user_name( $entry ) ); ?></span>
									</div>
								</td>
								<td>
									<span
										class="dtt-project-dot"
										style="background:<?php echo esc_attr( $entry->project_color ); ?>;"
										aria-hidden="true"
									></span>
									<?php echo esc_html( $entry->project_name ); ?>
								</td>
								<td><strong><?php echo esc_html( $entry->task_title ); ?></strong></td>
								<td><?php echo esc_html( self::format_datetime( $entry->start_time ) ); ?></td>
								<td><?php echo esc_html( self::format_duration( $entry->duration_seconds ) ); ?></td>
								<td><?php echo esc_html( self::format_amount( $entry->hourly_rate ) ); ?></td>
								<td>
									<strong class="<?php echo esc_attr( $entry->billable ? 'dtt-amount-billable' : 'dtt-amount-muted' ); ?>">
										<?php echo esc_html( self::format_amount( $total ) ); ?>
									</strong>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
		self::render_footer();
	}

	/**
	 * Display name for an entry, with a fallback.
	 *
	 * @param object $entry Entry row.
	 * @return string
	 */
	private static function entry_user_name( $entry ) {
		if ( ! empty( $entry->display_name ) ) {
			return $entry->display_name;
		}

		return __( 'Unknown user', 'dev-time-tracker' );
	}

	/**
	 * Timesheets screen.
	 */
	public static function render_timesheets() {
		self::render_header( 'timesheets' );

		$scope    = self::scope_user_id();
		$entries  = DTT_DB::get_entries(
			array(
				'user_id' => $scope,
				'limit'   => 200,
			)
		);
		$projects = DTT_Projects::all();
		?>
		<div class="dtt-wrap-inner">
			<div class="dtt-section-head">
				<div>
					<h2><?php echo esc_html__( 'Timesheets', 'dev-time-tracker' ); ?></h2>
					<p class="description">
						<?php
						echo self::can_view_all()
							? esc_html__( 'All logged sessions on this site, with duration and billing totals.', 'dev-time-tracker' )
							: esc_html__( 'Your logged sessions, with duration and billing totals.', 'dev-time-tracker' );
						?>
					</p>
				</div>
				<div class="dtt-section-actions">
					<button type="button" class="button" id="dtt-btn-open-manual" aria-expanded="false" aria-controls="dtt-manual-entry-card">
						<?php echo esc_html__( 'Add manual entry', 'dev-time-tracker' ); ?>
					</button>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'dtt_export_csv_action' ); ?>
						<input type="hidden" name="action" value="dtt_export_csv" />
						<button type="submit" class="button button-primary">
							<?php echo esc_html__( 'Export CSV', 'dev-time-tracker' ); ?>
						</button>
					</form>
				</div>
			</div>

			<div id="dtt-manual-entry-card" class="dtt-manual-card" hidden>
				<h3><?php echo esc_html__( 'Record a manual entry', 'dev-time-tracker' ); ?></h3>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'dtt_add_entry_action' ); ?>
					<input type="hidden" name="action" value="dtt_add_entry" />

					<div class="dtt-field-grid">
						<div>
							<label for="dtt-manual-task"><?php echo esc_html__( 'Task description', 'dev-time-tracker' ); ?></label>
							<input type="text" id="dtt-manual-task" name="task_title" required class="regular-text" />
						</div>
						<div>
							<label for="dtt-manual-project"><?php echo esc_html__( 'Project', 'dev-time-tracker' ); ?></label>
							<select id="dtt-manual-project" name="project_id">
								<?php foreach ( $projects as $project ) : ?>
									<option value="<?php echo esc_attr( $project['id'] ); ?>">
										<?php echo esc_html( $project['name'] ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
						<div>
							<label for="dtt-manual-hours"><?php echo esc_html__( 'Hours', 'dev-time-tracker' ); ?></label>
							<div class="dtt-duration-inputs">
								<input type="number" id="dtt-manual-hours" name="hours" value="1" min="0" max="24" step="1" />
								<label for="dtt-manual-minutes"><?php echo esc_html__( 'Minutes', 'dev-time-tracker' ); ?></label>
								<input type="number" id="dtt-manual-minutes" name="minutes" value="0" min="0" max="59" step="1" />
							</div>
						</div>
						<div>
							<label for="dtt-manual-rate"><?php echo esc_html__( 'Hourly rate', 'dev-time-tracker' ); ?></label>
							<input
								type="number"
								id="dtt-manual-rate"
								name="hourly_rate"
								step="0.01"
								min="0"
								value="<?php echo esc_attr( get_option( 'dtt_default_rate', 0 ) ); ?>"
							/>
						</div>
					</div>

					<div class="dtt-manual-footer">
						<label>
							<input
								type="checkbox"
								name="billable"
								value="1"
								<?php checked( (bool) get_option( 'dtt_default_billable', 1 ) ); ?>
							/>
							<?php echo esc_html__( 'Billable', 'dev-time-tracker' ); ?>
						</label>
						<button type="submit" class="button button-primary">
							<?php echo esc_html__( 'Save entry', 'dev-time-tracker' ); ?>
						</button>
					</div>
				</form>
			</div>

			<div class="dtt-table-card">
				<table class="dtt-table">
					<thead>
						<tr>
							<th scope="col"><?php echo esc_html__( 'Date', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'User', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Project', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Task', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Duration', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Rate', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Total', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Actions', 'dev-time-tracker' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $entries ) ) : ?>
							<tr>
								<td colspan="8" class="dtt-empty">
									<?php echo esc_html__( 'No timesheet entries yet.', 'dev-time-tracker' ); ?>
								</td>
							</tr>
						<?php else : ?>
							<?php foreach ( $entries as $entry ) : ?>
								<?php
								$hours     = $entry->duration_seconds / HOUR_IN_SECONDS;
								$total     = $entry->billable ? $hours * (float) $entry->hourly_rate : 0;
								$can_edit  = self::can_view_all() || (int) $entry->user_id === get_current_user_id();
								$delete_url = wp_nonce_url(
									admin_url( 'admin-post.php?action=dtt_delete_entry&id=' . (int) $entry->id ),
									'dtt_delete_entry_action'
								);
								?>
								<tr>
									<td><?php echo esc_html( self::format_datetime( $entry->start_time, get_option( 'date_format' ) ) ); ?></td>
									<td>
										<div class="dtt-user-cell">
											<?php echo get_avatar( $entry->user_id, 20 ); ?>
											<span><?php echo esc_html( self::entry_user_name( $entry ) ); ?></span>
										</div>
									</td>
									<td>
										<span
											class="dtt-project-dot"
											style="background:<?php echo esc_attr( $entry->project_color ); ?>;"
											aria-hidden="true"
										></span>
										<?php echo esc_html( $entry->project_name ); ?>
									</td>
									<td>
										<strong><?php echo esc_html( $entry->task_title ); ?></strong>
										<?php if ( ! empty( $entry->tags ) ) : ?>
											<div class="dtt-tag-list">
												<?php foreach ( explode( ',', $entry->tags ) as $tag ) : ?>
													<span class="dtt-tag-chip"><?php echo esc_html( trim( $tag ) ); ?></span>
												<?php endforeach; ?>
											</div>
										<?php endif; ?>
									</td>
									<td><?php echo esc_html( self::format_duration( $entry->duration_seconds ) ); ?></td>
									<td><?php echo esc_html( self::format_amount( $entry->hourly_rate ) ); ?></td>
									<td>
										<strong class="<?php echo esc_attr( $entry->billable ? 'dtt-amount-billable' : 'dtt-amount-muted' ); ?>">
											<?php echo esc_html( self::format_amount( $total ) ); ?>
										</strong>
									</td>
									<td>
										<?php if ( $can_edit ) : ?>
											<a
												href="<?php echo esc_url( $delete_url ); ?>"
												class="dtt-delete-link"
											><?php echo esc_html__( 'Delete', 'dev-time-tracker' ); ?></a>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
		self::render_footer();
	}

	/**
	 * Audit log screen.
	 */
	public static function render_audit_logs() {
		self::render_header( 'audit' );

		$logs    = DTT_Audit::get_recent_logs( 100 );
		$enabled = DTT_Audit::is_enabled();
		?>
		<div class="dtt-wrap-inner">
			<div class="dtt-dark-banner">
				<div>
					<h2>
						<span class="dashicons dashicons-shield" aria-hidden="true"></span>
						<?php echo esc_html__( 'Site activity log', 'dev-time-tracker' ); ?>
					</h2>
					<p>
						<?php echo esc_html__( 'When logging is enabled, the plugin records plugin activations, theme switches, the names of changed settings and post saves, along with the user responsible. Setting values are never stored.', 'dev-time-tracker' ); ?>
					</p>
				</div>
			</div>

			<?php if ( ! $enabled ) : ?>
				<div class="notice notice-info inline">
					<p>
						<?php echo esc_html__( 'Activity logging is currently off, so no new events are being recorded.', 'dev-time-tracker' ); ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=dtt-settings' ) ); ?>">
							<?php echo esc_html__( 'Turn it on in Settings', 'dev-time-tracker' ); ?>
						</a>
					</p>
				</div>
			<?php endif; ?>

			<div class="dtt-table-card">
				<table class="dtt-table">
					<thead>
						<tr>
							<th scope="col"><?php echo esc_html__( 'Event', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Target', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Description', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'User', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Time', 'dev-time-tracker' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $logs ) ) : ?>
							<tr>
								<td colspan="5" class="dtt-empty">
									<?php echo esc_html__( 'No activity recorded yet.', 'dev-time-tracker' ); ?>
								</td>
							</tr>
						<?php else : ?>
							<?php foreach ( $logs as $log ) : ?>
								<tr>
									<td>
										<span class="dtt-badge <?php echo esc_attr( $log->action ); ?>">
											<?php echo esc_html( self::action_label( $log->action ) ); ?>
										</span>
									</td>
									<td><code><?php echo esc_html( $log->target ); ?></code></td>
									<td>
										<div><?php echo esc_html( $log->summary ); ?></div>
										<?php if ( ! empty( $log->details ) ) : ?>
											<div class="dtt-log-details"><?php echo esc_html( $log->details ); ?></div>
										<?php endif; ?>
									</td>
									<td>
										<?php
										echo esc_html(
											! empty( $log->developer_name )
												? $log->developer_name
												: __( 'Unknown user', 'dev-time-tracker' )
										);
										?>
									</td>
									<td><?php echo esc_html( self::format_datetime( $log->time ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
		self::render_footer();
	}

	/**
	 * Human-readable label for an audit action key.
	 *
	 * @param string $action Action key.
	 * @return string
	 */
	private static function action_label( $action ) {
		$labels = array(
			'timer_start'   => __( 'Session start', 'dev-time-tracker' ),
			'timer_stop'    => __( 'Session end', 'dev-time-tracker' ),
			'plugin_change' => __( 'Plugin change', 'dev-time-tracker' ),
			'theme_update'  => __( 'Theme change', 'dev-time-tracker' ),
			'option_update' => __( 'Setting change', 'dev-time-tracker' ),
			'post_save'     => __( 'Content saved', 'dev-time-tracker' ),
		);

		if ( isset( $labels[ $action ] ) ) {
			return $labels[ $action ];
		}

		return ucwords( str_replace( '_', ' ', $action ) );
	}

	/**
	 * Reports and invoicing screen.
	 */
	public static function render_reports() {
		self::render_header( 'reports' );

		$summary    = DTT_DB::get_project_summary();
		$total_sec  = 0;
		$total_bill = 0.0;

		foreach ( $summary as $row ) {
			$total_sec  += (int) $row->total_seconds;
			$total_bill += (float) $row->total_billable;
		}
		?>
		<div class="dtt-wrap-inner">
			<div class="dtt-section-head">
				<div>
					<h2><?php echo esc_html__( 'Reports & invoicing', 'dev-time-tracker' ); ?></h2>
					<p class="description">
						<?php echo esc_html__( 'Totals grouped by project, plus a printable billing summary.', 'dev-time-tracker' ); ?>
					</p>
				</div>
				<div>
					<button type="button" id="dtt-btn-open-invoice" class="button button-primary">
						<?php echo esc_html__( 'Open billing summary', 'dev-time-tracker' ); ?>
					</button>
				</div>
			</div>

			<div class="dtt-kpi-grid">
				<div class="dtt-kpi-card">
					<div>
						<div class="dtt-kpi-label"><?php echo esc_html__( 'Total hours', 'dev-time-tracker' ); ?></div>
						<div class="dtt-kpi-val">
							<?php echo esc_html( number_format_i18n( $total_sec / HOUR_IN_SECONDS, 1 ) ); ?>
						</div>
					</div>
				</div>
				<div class="dtt-kpi-card">
					<div>
						<div class="dtt-kpi-label"><?php echo esc_html__( 'Total billable', 'dev-time-tracker' ); ?></div>
						<div class="dtt-kpi-val emerald"><?php echo esc_html( self::format_amount( $total_bill ) ); ?></div>
					</div>
				</div>
				<div class="dtt-kpi-card">
					<div>
						<div class="dtt-kpi-label"><?php echo esc_html__( 'Projects', 'dev-time-tracker' ); ?></div>
						<div class="dtt-kpi-val"><?php echo esc_html( number_format_i18n( count( $summary ) ) ); ?></div>
					</div>
				</div>
			</div>

			<div class="dtt-table-card dtt-spaced">
				<div class="dtt-table-card-header">
					<h2><?php echo esc_html__( 'Project breakdown', 'dev-time-tracker' ); ?></h2>
				</div>
				<table class="dtt-table">
					<thead>
						<tr>
							<th scope="col"><?php echo esc_html__( 'Project', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Hours', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Share', 'dev-time-tracker' ); ?></th>
							<th scope="col"><?php echo esc_html__( 'Billable', 'dev-time-tracker' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $summary ) ) : ?>
							<tr>
								<td colspan="4" class="dtt-empty">
									<?php echo esc_html__( 'No sessions recorded yet.', 'dev-time-tracker' ); ?>
								</td>
							</tr>
						<?php else : ?>
							<?php foreach ( $summary as $row ) : ?>
								<?php
								$hours = (int) $row->total_seconds / HOUR_IN_SECONDS;
								$pct   = $total_sec > 0 ? round( ( (int) $row->total_seconds / $total_sec ) * 100, 1 ) : 0;
								?>
								<tr>
									<td>
										<span
											class="dtt-project-dot"
											style="background:<?php echo esc_attr( $row->project_color ); ?>;"
											aria-hidden="true"
										></span>
										<strong><?php echo esc_html( $row->project_name ); ?></strong>
									</td>
									<td><?php echo esc_html( number_format_i18n( $hours, 2 ) ); ?></td>
									<td>
										<div class="dtt-progress-row">
											<div class="dtt-progress-track">
												<div
													class="dtt-progress-bar"
													style="width:<?php echo esc_attr( $pct ); ?>%;"
												></div>
											</div>
											<span><?php echo esc_html( number_format_i18n( $pct, 1 ) ); ?>%</span>
										</div>
									</td>
									<td>
										<strong class="dtt-amount-billable">
											<?php echo esc_html( self::format_amount( $row->total_billable ) ); ?>
										</strong>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>

			<?php self::render_invoice_modal( $summary, $total_sec, $total_bill ); ?>
		</div>
		<?php
		self::render_footer();
	}

	/**
	 * Printable billing summary dialog.
	 *
	 * @param array $summary    Project summary rows.
	 * @param int   $total_sec  Total seconds.
	 * @param float $total_bill Total billable amount.
	 */
	private static function render_invoice_modal( $summary, $total_sec, $total_bill ) {
		$site_name = get_bloginfo( 'name' );
		?>
		<div id="dtt-invoice-modal" class="dtt-modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="dtt-invoice-title">
			<div class="dtt-modal-dialog">
				<div class="dtt-modal-header">
					<strong id="dtt-invoice-title">
						<?php echo esc_html__( 'Development time & billing summary', 'dev-time-tracker' ); ?>
					</strong>
					<div class="dtt-modal-actions">
						<button type="button" class="button button-primary" id="dtt-btn-print">
							<?php echo esc_html__( 'Print or save as PDF', 'dev-time-tracker' ); ?>
						</button>
						<button type="button" class="dtt-modal-close button">
							<?php echo esc_html__( 'Close', 'dev-time-tracker' ); ?>
						</button>
					</div>
				</div>

				<div id="dtt-printable-invoice" class="dtt-invoice-body">
					<div class="dtt-inv-header">
						<div>
							<h2><?php echo esc_html__( 'Development time & billing summary', 'dev-time-tracker' ); ?></h2>
							<p>
								<?php
								printf(
									/* translators: 1: site name, 2: site URL. */
									esc_html__( 'Site: %1$s (%2$s)', 'dev-time-tracker' ),
									'<strong>' . esc_html( $site_name ) . '</strong>',
									esc_url( home_url() )
								);
								?>
							</p>
						</div>
						<div class="dtt-inv-meta">
							<p>
								<?php
								printf(
									/* translators: %s: formatted date. */
									esc_html__( 'Date: %s', 'dev-time-tracker' ),
									'<strong>' . esc_html( wp_date( get_option( 'date_format' ) ) ) . '</strong>'
								);
								?>
							</p>
						</div>
					</div>

					<div class="dtt-inv-client-grid">
						<div class="dtt-inv-client-box">
							<span class="dtt-inv-meta-label"><?php echo esc_html__( 'Prepared for', 'dev-time-tracker' ); ?></span>
							<div class="dtt-inv-client-name"><?php echo esc_html( $site_name ); ?></div>
							<div><?php echo esc_html( get_option( 'admin_email' ) ); ?></div>
						</div>
						<div class="dtt-inv-summary-box">
							<span class="dtt-inv-meta-label"><?php echo esc_html__( 'Total billable', 'dev-time-tracker' ); ?></span>
							<div class="dtt-inv-total-val"><?php echo esc_html( self::format_amount( $total_bill ) ); ?></div>
							<div>
								<?php
								printf(
									/* translators: %s: number of hours. */
									esc_html__( 'Hours logged: %s', 'dev-time-tracker' ),
									'<strong>' . esc_html( number_format_i18n( $total_sec / HOUR_IN_SECONDS, 2 ) ) . '</strong>'
								);
								?>
							</div>
						</div>
					</div>

					<h3><?php echo esc_html__( 'Breakdown by project', 'dev-time-tracker' ); ?></h3>
					<table class="dtt-inv-table">
						<thead>
							<tr>
								<th scope="col"><?php echo esc_html__( 'Project', 'dev-time-tracker' ); ?></th>
								<th scope="col" class="dtt-right"><?php echo esc_html__( 'Hours', 'dev-time-tracker' ); ?></th>
								<th scope="col" class="dtt-right"><?php echo esc_html__( 'Effective rate', 'dev-time-tracker' ); ?></th>
								<th scope="col" class="dtt-right"><?php echo esc_html__( 'Subtotal', 'dev-time-tracker' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $summary as $row ) : ?>
								<?php
								$hours = (int) $row->total_seconds / HOUR_IN_SECONDS;
								$rate  = $hours > 0 ? ( (float) $row->total_billable / $hours ) : 0;
								?>
								<tr>
									<td><strong><?php echo esc_html( $row->project_name ); ?></strong></td>
									<td class="dtt-right"><?php echo esc_html( number_format_i18n( $hours, 2 ) ); ?></td>
									<td class="dtt-right"><?php echo esc_html( self::format_amount( $rate ) ); ?></td>
									<td class="dtt-right"><strong><?php echo esc_html( self::format_amount( $row->total_billable ) ); ?></strong></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>

					<div class="dtt-inv-footer-bar">
						<div class="dtt-inv-audit-badge">
							<?php echo esc_html__( 'Figures come from time entries stored on this site.', 'dev-time-tracker' ); ?>
						</div>
						<div class="dtt-inv-total-due">
							<span><?php echo esc_html__( 'Total:', 'dev-time-tracker' ); ?></span>
							<strong><?php echo esc_html( self::format_amount( $total_bill ) ); ?></strong>
						</div>
					</div>

					<p class="dtt-inv-note">
						<?php
						printf(
							/* translators: %s: formatted date and time. */
							esc_html__( 'Generated: %s', 'dev-time-tracker' ),
							esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) )
						);
						?>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Settings screen.
	 */
	public static function render_settings() {
		self::render_header( 'settings' );

		$auto_prompt      = (int) get_option( 'dtt_auto_prompt', 0 );
		$idle_minutes     = (int) get_option( 'dtt_idle_minutes', 10 );
		$require_task     = (int) get_option( 'dtt_require_task', 1 );
		$default_rate     = get_option( 'dtt_default_rate', 0 );
		$currency         = (string) get_option( 'dtt_currency', '$' );
		$currency_options = self::get_currency_options();
		$currency_custom  = array_key_exists( $currency, $currency_options ) ? '' : $currency;
		$default_billable = (int) get_option( 'dtt_default_billable', 1 );
		$notify_email     = get_option( 'dtt_notify_email', '' );
		$notify_logout    = (int) get_option( 'dtt_notify_logout', 0 );
		$audit_enabled    = (int) get_option( 'dtt_audit_enabled', 0 );
		$retention        = (int) get_option( 'dtt_audit_retention_days', 90 );
		$projects         = DTT_Projects::all();

		$idle_choices = array(
			5  => __( '5 minutes', 'dev-time-tracker' ),
			10 => __( '10 minutes', 'dev-time-tracker' ),
			15 => __( '15 minutes', 'dev-time-tracker' ),
			30 => __( '30 minutes', 'dev-time-tracker' ),
			0  => __( 'Disabled', 'dev-time-tracker' ),
		);

		$retention_choices = array(
			30  => __( '30 days', 'dev-time-tracker' ),
			90  => __( '90 days', 'dev-time-tracker' ),
			180 => __( '180 days', 'dev-time-tracker' ),
			365 => __( '1 year', 'dev-time-tracker' ),
			0   => __( 'Keep indefinitely', 'dev-time-tracker' ),
		);
		?>
		<div class="dtt-wrap-inner dtt-settings">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'dtt_save_settings_action' ); ?>
				<input type="hidden" name="action" value="dtt_save_settings" />

				<div class="dtt-settings-card">
					<div class="dtt-settings-card-header">
						<span class="dashicons dashicons-clock" aria-hidden="true"></span>
						<h3><?php echo esc_html__( 'Sessions', 'dev-time-tracker' ); ?></h3>
					</div>

					<div class="dtt-setting-row">
						<div class="dtt-setting-info">
							<label for="dtt_auto_prompt"><?php echo esc_html__( 'Prompt to start the timer after login', 'dev-time-tracker' ); ?></label>
							<p><?php echo esc_html__( 'Shows a dismissible dialog on the dashboard once after signing in, asking whether to clock in.', 'dev-time-tracker' ); ?></p>
						</div>
						<div>
							<input type="checkbox" id="dtt_auto_prompt" name="dtt_auto_prompt" value="1" <?php checked( $auto_prompt, 1 ); ?> />
						</div>
					</div>

					<div class="dtt-setting-row">
						<div class="dtt-setting-info">
							<label for="dtt_idle_minutes"><?php echo esc_html__( 'Idle reminder', 'dev-time-tracker' ); ?></label>
							<p><?php echo esc_html__( 'Shows a reminder in the browser when no activity is detected while the timer runs.', 'dev-time-tracker' ); ?></p>
						</div>
						<div>
							<select id="dtt_idle_minutes" name="dtt_idle_minutes">
								<?php foreach ( $idle_choices as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $idle_minutes, $value ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>

					<div class="dtt-setting-row">
						<div class="dtt-setting-info">
							<label for="dtt_require_task"><?php echo esc_html__( 'Require a task description', 'dev-time-tracker' ); ?></label>
							<p><?php echo esc_html__( 'Prevents starting the timer without describing the work.', 'dev-time-tracker' ); ?></p>
						</div>
						<div>
							<input type="checkbox" id="dtt_require_task" name="dtt_require_task" value="1" <?php checked( $require_task, 1 ); ?> />
						</div>
					</div>
				</div>

				<div class="dtt-settings-card">
					<div class="dtt-settings-card-header">
						<span class="dashicons dashicons-money-alt" aria-hidden="true"></span>
						<h3><?php echo esc_html__( 'Rates & billing', 'dev-time-tracker' ); ?></h3>
					</div>

					<div class="dtt-field-grid">
						<div>
							<label for="dtt_default_rate"><?php echo esc_html__( 'Default hourly rate', 'dev-time-tracker' ); ?></label>
							<input
								type="number"
								step="0.01"
								min="0"
								id="dtt_default_rate"
								name="dtt_default_rate"
								value="<?php echo esc_attr( $default_rate ); ?>"
								class="regular-text"
							/>
						</div>
						<div>
							<label for="dtt_currency"><?php echo esc_html__( 'Currency', 'dev-time-tracker' ); ?></label>
							<select id="dtt_currency" name="dtt_currency" class="regular-text">
								<?php foreach ( $currency_options as $symbol => $label ) : ?>
									<option value="<?php echo esc_attr( $symbol ); ?>" <?php selected( $currency, $symbol ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
								<option value="custom" <?php selected( '' !== $currency_custom ); ?>>
									<?php echo esc_html__( 'Custom…', 'dev-time-tracker' ); ?>
								</option>
							</select>
							<input
								type="text"
								id="dtt_currency_custom"
								name="dtt_currency_custom"
								value="<?php echo esc_attr( $currency_custom ); ?>"
								class="regular-text"
								maxlength="12"
								placeholder="<?php echo esc_attr__( 'e.g. Fr', 'dev-time-tracker' ); ?>"
								<?php echo esc_attr( '' === $currency_custom ? 'hidden' : '' ); ?>
							/>
						</div>
					</div>

					<div class="dtt-setting-row">
						<div class="dtt-setting-info">
							<label for="dtt_default_billable"><?php echo esc_html__( 'Mark new sessions as billable', 'dev-time-tracker' ); ?></label>
							<p><?php echo esc_html__( 'Sets the default billable state for new sessions and entries.', 'dev-time-tracker' ); ?></p>
						</div>
						<div>
							<input type="checkbox" id="dtt_default_billable" name="dtt_default_billable" value="1" <?php checked( $default_billable, 1 ); ?> />
						</div>
					</div>
				</div>

				<div class="dtt-settings-card">
					<div class="dtt-settings-card-header">
						<span class="dashicons dashicons-portfolio" aria-hidden="true"></span>
						<h3><?php echo esc_html__( 'Projects', 'dev-time-tracker' ); ?></h3>
					</div>
					<p class="dtt-settings-card-desc">
						<?php echo esc_html__( 'Projects appear in the timer dropdown. Each can carry its own hourly rate, which overrides the default above.', 'dev-time-tracker' ); ?>
					</p>

					<table class="dtt-table dtt-projects-table">
						<thead>
							<tr>
								<th scope="col"><?php echo esc_html__( 'Name', 'dev-time-tracker' ); ?></th>
								<th scope="col"><?php echo esc_html__( 'Client', 'dev-time-tracker' ); ?></th>
								<th scope="col"><?php echo esc_html__( 'Colour', 'dev-time-tracker' ); ?></th>
								<th scope="col"><?php echo esc_html__( 'Rate', 'dev-time-tracker' ); ?></th>
								<th scope="col"><?php echo esc_html__( 'Remove', 'dev-time-tracker' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $projects as $index => $project ) : ?>
								<?php $field = 'dtt_projects[' . $project['id'] . ']'; ?>
								<tr>
									<td>
										<label class="screen-reader-text" for="dtt-project-name-<?php echo esc_attr( $index ); ?>">
											<?php echo esc_html__( 'Project name', 'dev-time-tracker' ); ?>
										</label>
										<input
											type="hidden"
											name="<?php echo esc_attr( $field ); ?>[id]"
											value="<?php echo esc_attr( $project['id'] ); ?>"
										/>
										<input
											type="text"
											id="dtt-project-name-<?php echo esc_attr( $index ); ?>"
											name="<?php echo esc_attr( $field ); ?>[name]"
											value="<?php echo esc_attr( $project['name'] ); ?>"
										/>
									</td>
									<td>
										<label class="screen-reader-text" for="dtt-project-client-<?php echo esc_attr( $index ); ?>">
											<?php echo esc_html__( 'Client', 'dev-time-tracker' ); ?>
										</label>
										<input
											type="text"
											id="dtt-project-client-<?php echo esc_attr( $index ); ?>"
											name="<?php echo esc_attr( $field ); ?>[client]"
											value="<?php echo esc_attr( $project['client'] ); ?>"
										/>
									</td>
									<td>
										<label class="screen-reader-text" for="dtt-project-color-<?php echo esc_attr( $index ); ?>">
											<?php echo esc_html__( 'Colour', 'dev-time-tracker' ); ?>
										</label>
										<input
											type="color"
											id="dtt-project-color-<?php echo esc_attr( $index ); ?>"
											name="<?php echo esc_attr( $field ); ?>[color]"
											value="<?php echo esc_attr( $project['color'] ); ?>"
										/>
									</td>
									<td>
										<label class="screen-reader-text" for="dtt-project-rate-<?php echo esc_attr( $index ); ?>">
											<?php echo esc_html__( 'Hourly rate', 'dev-time-tracker' ); ?>
										</label>
										<input
											type="number"
											step="0.01"
											min="0"
											id="dtt-project-rate-<?php echo esc_attr( $index ); ?>"
											name="<?php echo esc_attr( $field ); ?>[rate]"
											value="<?php echo esc_attr( $project['rate'] ); ?>"
										/>
									</td>
									<td>
										<label class="screen-reader-text" for="dtt-project-remove-<?php echo esc_attr( $index ); ?>">
											<?php echo esc_html__( 'Remove this project', 'dev-time-tracker' ); ?>
										</label>
										<input
											type="checkbox"
											id="dtt-project-remove-<?php echo esc_attr( $index ); ?>"
											name="<?php echo esc_attr( $field ); ?>[remove]"
											value="1"
										/>
									</td>
								</tr>
							<?php endforeach; ?>
							<tr>
								<td>
									<label class="screen-reader-text" for="dtt-new-project-name">
										<?php echo esc_html__( 'New project name', 'dev-time-tracker' ); ?>
									</label>
									<input
										type="text"
										id="dtt-new-project-name"
										name="dtt_new_project[name]"
										placeholder="<?php echo esc_attr__( 'Add a project', 'dev-time-tracker' ); ?>"
									/>
								</td>
								<td>
									<label class="screen-reader-text" for="dtt-new-project-client">
										<?php echo esc_html__( 'New project client', 'dev-time-tracker' ); ?>
									</label>
									<input type="text" id="dtt-new-project-client" name="dtt_new_project[client]" />
								</td>
								<td>
									<label class="screen-reader-text" for="dtt-new-project-color">
										<?php echo esc_html__( 'New project colour', 'dev-time-tracker' ); ?>
									</label>
									<input type="color" id="dtt-new-project-color" name="dtt_new_project[color]" value="#2271b1" />
								</td>
								<td>
									<label class="screen-reader-text" for="dtt-new-project-rate">
										<?php echo esc_html__( 'New project rate', 'dev-time-tracker' ); ?>
									</label>
									<input
										type="number"
										step="0.01"
										min="0"
										id="dtt-new-project-rate"
										name="dtt_new_project[rate]"
										value="<?php echo esc_attr( $default_rate ); ?>"
									/>
								</td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="dtt-settings-card">
					<div class="dtt-settings-card-header">
						<span class="dashicons dashicons-shield" aria-hidden="true"></span>
						<h3><?php echo esc_html__( 'Activity logging', 'dev-time-tracker' ); ?></h3>
					</div>
					<p class="dtt-settings-card-desc">
						<?php echo esc_html__( 'Off by default. When enabled, the plugin records plugin activations, theme switches, the names of changed settings and post saves, along with the user responsible. Setting values are never stored, and nothing leaves this site.', 'dev-time-tracker' ); ?>
					</p>

					<div class="dtt-setting-row">
						<div class="dtt-setting-info">
							<label for="dtt_audit_enabled"><?php echo esc_html__( 'Record site activity', 'dev-time-tracker' ); ?></label>
						</div>
						<div>
							<input type="checkbox" id="dtt_audit_enabled" name="dtt_audit_enabled" value="1" <?php checked( $audit_enabled, 1 ); ?> />
						</div>
					</div>

					<div class="dtt-setting-row">
						<div class="dtt-setting-info">
							<label for="dtt_audit_retention_days"><?php echo esc_html__( 'Keep log entries for', 'dev-time-tracker' ); ?></label>
							<p><?php echo esc_html__( 'Older entries are deleted automatically once a day.', 'dev-time-tracker' ); ?></p>
						</div>
						<div>
							<select id="dtt_audit_retention_days" name="dtt_audit_retention_days">
								<?php foreach ( $retention_choices as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $retention, $value ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>

				<div class="dtt-settings-card">
					<div class="dtt-settings-card-header">
						<span class="dashicons dashicons-email" aria-hidden="true"></span>
						<h3><?php echo esc_html__( 'Email notifications', 'dev-time-tracker' ); ?></h3>
					</div>
					<p class="dtt-settings-card-desc">
						<?php echo esc_html__( 'Off by default. When enabled, a short summary is emailed each time a session is stopped. Emails are sent from this site only, using the address below.', 'dev-time-tracker' ); ?>
					</p>

					<div class="dtt-field-single">
						<label for="dtt_notify_email"><?php echo esc_html__( 'Recipient address', 'dev-time-tracker' ); ?></label>
						<input
							type="email"
							id="dtt_notify_email"
							name="dtt_notify_email"
							value="<?php echo esc_attr( $notify_email ); ?>"
							class="regular-text"
							placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>"
						/>
						<p class="description">
							<?php echo esc_html__( 'Leave blank to use the site administration email address.', 'dev-time-tracker' ); ?>
						</p>
					</div>

					<div class="dtt-setting-row">
						<div class="dtt-setting-info">
							<label for="dtt_notify_logout"><?php echo esc_html__( 'Email a summary when a session is stopped', 'dev-time-tracker' ); ?></label>
						</div>
						<div>
							<input type="checkbox" id="dtt_notify_logout" name="dtt_notify_logout" value="1" <?php checked( $notify_logout, 1 ); ?> />
						</div>
					</div>
				</div>

				<?php submit_button( __( 'Save settings', 'dev-time-tracker' ) ); ?>
			</form>
		</div>
		<?php
		self::render_footer();
	}

	/**
	 * Dismissible clock-in prompt shown once after login.
	 */
	public static function render_login_modal() {
		$projects = DTT_Projects::all();
		?>
		<div
			id="dtt-login-modal"
			class="dtt-login-modal"
			role="dialog"
			aria-modal="true"
			aria-labelledby="dtt-login-modal-title"
		>
			<div class="dtt-login-modal-inner">
				<div class="dtt-login-modal-head">
					<span class="dashicons dashicons-clock" aria-hidden="true"></span>
					<h2 id="dtt-login-modal-title"><?php echo esc_html__( 'Start tracking time?', 'dev-time-tracker' ); ?></h2>
				</div>
				<p><?php echo esc_html__( 'You can start the timer now, or skip and start it later from the Dev Tracker screen.', 'dev-time-tracker' ); ?></p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'dtt_start_timer_action' ); ?>
					<input type="hidden" name="action" value="dtt_start_timer" />
					<input
						type="hidden"
						name="billable"
						value="<?php echo esc_attr( get_option( 'dtt_default_billable', 1 ) ? '1' : '0' ); ?>"
					/>

					<p>
						<label for="dtt-modal-task"><?php echo esc_html__( 'Task description', 'dev-time-tracker' ); ?></label><br />
						<input type="text" id="dtt-modal-task" name="task_title" required class="regular-text" />
					</p>

					<p>
						<label for="dtt-modal-project"><?php echo esc_html__( 'Project', 'dev-time-tracker' ); ?></label><br />
						<select id="dtt-modal-project" name="project_id">
							<?php foreach ( $projects as $project ) : ?>
								<option value="<?php echo esc_attr( $project['id'] ); ?>">
									<?php echo esc_html( $project['name'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</p>

					<div class="dtt-login-modal-actions">
						<button type="button" class="button" id="dtt-login-modal-dismiss">
							<?php echo esc_html__( 'Not now', 'dev-time-tracker' ); ?>
						</button>
						<button type="submit" class="button button-primary">
							<?php echo esc_html__( 'Start timer', 'dev-time-tracker' ); ?>
						</button>
					</div>
				</form>
			</div>
		</div>
		<?php
	}
}
