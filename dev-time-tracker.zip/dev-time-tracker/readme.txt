=== Dev Time Tracker ===
Contributors: peterkagunda
Tags: time tracking, timesheet, billable hours, activity log, invoice
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Track development time from the admin bar, keep an optional activity log, and produce billable summaries. All data stays on your site.

== Description ==

Dev Time Tracker is a self-contained time tracker for people who build and maintain sites. Start a timer from the admin bar, note what you worked on, and the entry is saved to your own database with its project, duration and rate.

It is aimed at freelancers and agencies who need to show a client where the hours went, but it works just as well for keeping your own record.

Everything runs locally. The plugin makes no external HTTP requests, contains no analytics or tracking, and sends no data to the author or any third party.

= What it does =

* A start/stop timer on the plugin screen and a live counter in the admin bar.
* Manual entries for work done away from the keyboard.
* Projects you define yourself, each with its own client name, colour and hourly rate.
* Timesheets with duration and billable totals, plus CSV export.
* An optional activity log recording plugin activations, theme switches, changed setting names and post saves.
* Per-project reports and a printable billing summary.
* REST endpoints under `dev-time-tracker/v1` for your own tooling.

= Permissions =

Users who can edit posts can track their own time and see their own timesheets. Administrators can see everyone's entries, the activity log, reports and settings.

= Privacy =

The plugin stores time entries in two custom tables in your site's database. Each entry records the user who created it, a task description, a project name, start and end times, an hourly rate and whether the time is billable.

If you switch on activity logging, the plugin also records which user activated or deactivated a plugin, switched themes, changed a setting or saved a post. Only the **name** of a changed setting is stored, never its value. Log entries are deleted automatically after the retention period you choose.

Activity logging and email notifications are both off until you turn them on. Session summary emails, when enabled, are sent from your site by WordPress to the address you configure.

Time entries are included in WordPress's personal data export and erase tools, and the plugin adds suggested wording to your privacy policy draft.

== Installation ==

1. Upload the `dev-time-tracker` folder to `/wp-content/plugins/`, or install the ZIP through Plugins > Add New.
2. Activate the plugin through the Plugins menu.
3. Open Dev Tracker > Settings to add your projects and set a default hourly rate.
4. Start the timer from Dev Tracker > Dashboard & Timer or from the admin bar.

== Frequently Asked Questions ==

= Does this send my data anywhere? =

No. There are no external requests of any kind. Everything is stored in your own database, and the only outbound mail is the optional session summary, which WordPress sends to the address you choose.

= Can other users see my time entries? =

Only administrators can see other users' entries. Everyone else sees their own.

= Is the activity log on by default? =

No. It is off until you enable it in Settings. When enabled it records only the names of changed settings, never their values.

= What happens to my data if I delete the plugin? =

Deactivating keeps everything. Deleting the plugin from the Plugins screen removes both custom tables and all plugin options, on every site of a multisite network.

= Can I use the REST API? =

Yes. Routes live under `dev-time-tracker/v1` and require a logged-in user with the matching capability. Send a `wp_rest` nonce with each request.

== Screenshots ==

1. Dashboard with the running timer and today's totals.
2. Timesheets with duration and billable totals.
3. Project and rate settings.
4. Printable billing summary.

== Changelog ==

= 1.0.0 =
* Activation no longer stores a default project. A new install now has zero rows in projects, timesheets, and settings beyond plain defaults — the tracker and settings screens still show a starter "General development" project to work with, but nothing is written to the database until you actually save settings or track time.
* The currency field is now a dropdown of common currencies (USD, EUR, GBP, KES, NGN, ZAR, INR, JPY, AUD, CAD, CHF) with a "Custom…" option that reveals a text field for anything else.
* Removed a helper method that read `$_POST` outside the handler that verifies the request's nonce; the same sanitization now happens inline in each handler right after its own `check_admin_referer()` call.
* Numeric fields (hours, minutes, hourly rate, default rate) now use `floatval()` explicitly instead of a cast, so the value is sanitized right where it's read.
* The submitted project list and new-project fields are now sanitized field-by-field with `map_deep()` at the point they're read from `$_POST`, before further validation.
* A couple of admin-screen CSS classes were escaped with `esc_attr()` for defense in depth, even though their possible values were already hardcoded.

= 1.1.0 =
* Removed the sample projects, entries and audit rows that were created on activation. Activation now adds a single empty project and nothing else.
* Removed the audit log test buttons, which wrote fabricated events describing changes that had not happened.
* Projects, clients and rates are now defined in Settings instead of hardcoded.
* Activity logging is now opt-in, skips transient and cron noise, never stores setting values, and prunes itself on a schedule you choose.
* Email notifications are now opt-in and default to the site administration address. Removed the hardcoded third-party recipient.
* Non-administrators now see only their own entries in timesheets, exports and the REST API. Removed email addresses from API responses.
* Fixed the `/entries` route, where the POST registration overwrote the GET registration.
* Escaped all output, unslashed and sanitized all input, and added prepared identifiers to every database query.
* Fixed elapsed time on sites not running in UTC; all dates now use the site's timezone and date format.
* Fixed the currency symbol parser, which never matched and silently dropped the symbol.
* Admin CSS and JS are now loaded only on the plugin's own screens; the admin bar loads a small separate stylesheet.
* Added personal data export and erase handlers and suggested privacy policy text.
* Added object caching to all read queries.
* Removed the deprecated `null` parent in `add_submenu_page()` and the manual `load_plugin_textdomain()` call.

= 1.0.0 =
* First release.

== Upgrade Notice ==

= 1.1.0 =
Security and privacy release. Sample data and the audit log test buttons are gone, activity logging and emails are now opt-in, and non-administrators no longer see other users' entries. Projects move from hardcoded values to Settings; review them after updating.
