<?php
/**
 * Plugin Name:       Dev Time Tracker
 * Plugin URI:        https://peterkagunda.com
 * Description:       Track development time, log site changes to an audit trail, and produce billable summaries for clients. All data stays on your own site.
 * Version:           1.0.0
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Peter Kagunda
 * Author URI:        https://peterkagunda.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       dev-time-tracker
 *
 * @package DevTimeTracker
 */

/**
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for details.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DEVTIME_VERSION', '1.0.1' );
define( 'DEVTIME_PATH', plugin_dir_path( __FILE__ ) );
define( 'DEVTIME_URL', plugin_dir_url( __FILE__ ) );
define( 'DEVTIME_BASENAME', plugin_basename( __FILE__ ) );

require_once DEVTIME_PATH . 'includes/class-dtt-db.php';
require_once DEVTIME_PATH . 'includes/class-dtt-projects.php';
require_once DEVTIME_PATH . 'includes/class-dtt-audit.php';
require_once DEVTIME_PATH . 'includes/class-dtt-rest.php';
require_once DEVTIME_PATH . 'includes/class-dtt-admin-bar.php';
require_once DEVTIME_PATH . 'includes/class-dtt-privacy.php';
require_once DEVTIME_PATH . 'includes/class-dtt-admin-view.php';

/**
 * Main plugin controller.
 */
final class Dev_Time_Tracker {

	/**
	 * Capability required to track and view your own time.
	 *
	 * @var string
	 */
	const CAP_TRACK = 'edit_posts';

	/**
	 * Capability required to manage settings, audit logs and other users' data.
	 *
	 * @var string
	 */
	const CAP_MANAGE = 'manage_options';

	/**
	 * Singleton instance.
	 *
	 * @var Dev_Time_Tracker|null
	 */
	private static $instance = null;

	/**
	 * Screen IDs belonging to this plugin.
	 *
	 * @var string[]
	 */
	private $plugin_hooks = array();

	/**
	 * Retrieve the singleton instance.
	 *
	 * @return Dev_Time_Tracker
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register hooks.
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init_plugin' ) );
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_admin_bar_style' ) );
		add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_widget' ) );
		add_action( 'wp_login', array( $this, 'on_user_login' ), 10, 2 );
		add_action( 'admin_init', array( $this, 'handle_legacy_redirect' ) );
		add_action( 'admin_footer', array( $this, 'render_admin_modals' ) );

		// Form handlers.
		add_action( 'admin_post_dtt_start_timer', array( $this, 'handle_start_timer' ) );
		add_action( 'admin_post_dtt_stop_timer', array( $this, 'handle_stop_timer' ) );
		add_action( 'admin_post_dtt_add_milestone', array( $this, 'handle_add_milestone' ) );
		add_action( 'admin_post_dtt_add_entry', array( $this, 'handle_add_entry' ) );
		add_action( 'admin_post_dtt_delete_entry', array( $this, 'handle_delete_entry' ) );
		add_action( 'admin_post_dtt_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_dtt_export_csv', array( $this, 'handle_export_csv' ) );
	}

	/**
	 * Bootstrap sub-modules once WordPress is loaded.
	 */
	public function init_plugin() {
		DTT_DB::maybe_upgrade();
		DTT_REST::init();
		DTT_Admin_Bar::init();
		DTT_Audit::init();
		DTT_Privacy::init();
	}

	/**
	 * Redirect the slug used by earlier releases to the current one.
	 */
	public function handle_legacy_redirect() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing, no state is changed.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		if ( 'wp-devtime-tracker' === $page ) {
			wp_safe_redirect( admin_url( 'admin.php?page=dev-time-tracker' ) );
			exit;
		}
	}

	/**
	 * Register the admin menu and sub pages.
	 */
	public function register_admin_menu() {
		if ( ! current_user_can( self::CAP_TRACK ) ) {
			return;
		}

		$this->plugin_hooks = array();

		$this->plugin_hooks[] = add_menu_page(
			__( 'Dev Time Tracker', 'dev-time-tracker' ),
			__( 'Dev Tracker', 'dev-time-tracker' ),
			self::CAP_TRACK,
			'dev-time-tracker',
			array( $this, 'render_tracker_page' ),
			'dashicons-clock',
			80
		);

		$this->plugin_hooks[] = add_submenu_page(
			'dev-time-tracker',
			__( 'Dashboard & Timer', 'dev-time-tracker' ),
			__( 'Dashboard & Timer', 'dev-time-tracker' ),
			self::CAP_TRACK,
			'dev-time-tracker',
			array( $this, 'render_tracker_page' )
		);

		$this->plugin_hooks[] = add_submenu_page(
			'dev-time-tracker',
			__( 'Timesheets & Entries', 'dev-time-tracker' ),
			__( 'Timesheets', 'dev-time-tracker' ),
			self::CAP_TRACK,
			'dtt-timesheets',
			array( $this, 'render_timesheets_page' )
		);

		$this->plugin_hooks[] = add_submenu_page(
			'dev-time-tracker',
			__( 'Activity Audit Log', 'dev-time-tracker' ),
			__( 'Audit Log', 'dev-time-tracker' ),
			self::CAP_MANAGE,
			'dtt-audit',
			array( $this, 'render_audit_page' )
		);

		$this->plugin_hooks[] = add_submenu_page(
			'dev-time-tracker',
			__( 'Reports & Invoicing', 'dev-time-tracker' ),
			__( 'Reports', 'dev-time-tracker' ),
			self::CAP_MANAGE,
			'dtt-reports',
			array( $this, 'render_reports_page' )
		);

		$this->plugin_hooks[] = add_submenu_page(
			'dev-time-tracker',
			__( 'Tracker Settings', 'dev-time-tracker' ),
			__( 'Settings', 'dev-time-tracker' ),
			self::CAP_MANAGE,
			'dtt-settings',
			array( $this, 'render_settings_page' )
		);

		$this->plugin_hooks = array_filter( $this->plugin_hooks );
	}

	/**
	 * Determine whether the current screen belongs to this plugin.
	 *
	 * @param string $hook Current admin page hook suffix.
	 * @return bool
	 */
	private function is_plugin_screen( $hook ) {
		return in_array( $hook, $this->plugin_hooks, true );
	}

	/**
	 * Enqueue admin styles and scripts only where they are used.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_admin_assets( $hook ) {
		$this->enqueue_admin_bar_style();

		$needs_ui = $this->is_plugin_screen( $hook ) || 'index.php' === $hook;

		if ( ! $needs_ui ) {
			return;
		}

		wp_enqueue_style(
			'dtt-admin-style',
			DEVTIME_URL . 'assets/css/tracker-admin.css',
			array(),
			DEVTIME_VERSION
		);

		wp_enqueue_script(
			'dtt-admin-script',
			DEVTIME_URL . 'assets/js/tracker-admin.js',
			array( 'jquery' ),
			DEVTIME_VERSION,
			true
		);

		wp_localize_script(
			'dtt-admin-script',
			'dttConfig',
			array(
				'root'        => esc_url_raw( rest_url( 'dev-time-tracker/v1' ) ),
				'nonce'       => wp_create_nonce( 'wp_rest' ),
				'idleMinutes' => (int) get_option( 'dtt_idle_minutes', 10 ),
				'i18n'        => array(
					'idleNotice'   => __( 'No activity detected for a while. Your timer is still running.', 'dev-time-tracker' ),
					'confirmDelete' => __( 'Delete this timesheet entry?', 'dev-time-tracker' ),
				),
			)
		);
	}

	/**
	 * Enqueue the small stylesheet used by the admin bar ticker.
	 */
	public function enqueue_admin_bar_style() {
		if ( ! is_admin_bar_showing() || ! current_user_can( self::CAP_TRACK ) ) {
			return;
		}

		wp_enqueue_style(
			'dtt-admin-bar',
			DEVTIME_URL . 'assets/css/admin-bar.css',
			array(),
			DEVTIME_VERSION
		);
	}

	/**
	 * Register the dashboard summary widget.
	 */
	public function register_dashboard_widget() {
		if ( ! current_user_can( self::CAP_TRACK ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'dtt_dashboard_widget',
			__( 'Developer Time Tracker Summary', 'dev-time-tracker' ),
			array( $this, 'render_dashboard_widget_content' )
		);
	}

	/**
	 * Output the dashboard widget contents.
	 */
	public function render_dashboard_widget_content() {
		$total_today = DTT_DB::get_today_seconds( get_current_user_id() );
		$hours       = (int) floor( $total_today / HOUR_IN_SECONDS );
		$minutes     = (int) floor( ( $total_today % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS );

		echo '<div class="dtt-widget-wrap">';
		echo '<div class="dtt-widget-metric">';
		echo '<span class="dtt-label">' . esc_html__( 'Tracked today:', 'dev-time-tracker' ) . '</span> ';
		echo '<strong class="dtt-big">' . esc_html( sprintf( '%02dh %02dm', $hours, $minutes ) ) . '</strong>';
		echo '</div>';
		echo '<a href="' . esc_url( admin_url( 'admin.php?page=dev-time-tracker' ) ) . '" class="button button-primary">';
		echo esc_html__( 'Open tracker', 'dev-time-tracker' );
		echo '</a>';
		echo '</div>';
	}

	/**
	 * Flag a clock-in prompt for the user who just logged in.
	 *
	 * @param string  $user_login Username.
	 * @param WP_User $user       User object.
	 */
	public function on_user_login( $user_login, $user ) {
		if ( ! $user instanceof WP_User ) {
			return;
		}

		if ( ! get_option( 'dtt_auto_prompt', 0 ) ) {
			return;
		}

		if ( ! user_can( $user, self::CAP_TRACK ) ) {
			return;
		}

		set_transient( 'dtt_prompt_login_' . $user->ID, 1, 5 * MINUTE_IN_SECONDS );
	}

	/**
	 * Render the clock-in prompt, limited to the dashboard and plugin screens.
	 */
	public function render_admin_modals() {
		if ( ! current_user_can( self::CAP_TRACK ) ) {
			return;
		}

		if ( ! get_option( 'dtt_auto_prompt', 0 ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( ! $screen ) {
			return;
		}

		$allowed = 'dashboard' === $screen->id || $this->is_plugin_screen( $screen->id );

		if ( ! $allowed ) {
			return;
		}

		$user_id = get_current_user_id();

		if ( ! get_transient( 'dtt_prompt_login_' . $user_id ) ) {
			return;
		}

		delete_transient( 'dtt_prompt_login_' . $user_id );

		if ( DTT_DB::get_active_session( $user_id ) ) {
			return;
		}

		DTT_Admin_View::render_login_modal();
	}

	/**
	 * Render the dashboard screen.
	 */
	public function render_tracker_page() {
		DTT_Admin_View::render_dashboard();
	}

	/**
	 * Render the timesheets screen.
	 */
	public function render_timesheets_page() {
		DTT_Admin_View::render_timesheets();
	}

	/**
	 * Render the audit log screen.
	 */
	public function render_audit_page() {
		DTT_Admin_View::render_audit_logs();
	}

	/**
	 * Render the reports screen.
	 */
	public function render_reports_page() {
		DTT_Admin_View::render_reports();
	}

	/**
	 * Render the settings screen.
	 */
	public function render_settings_page() {
		DTT_Admin_View::render_settings();
	}

	/**
	 * Stop processing if the current user lacks a capability.
	 *
	 * @param string $capability Capability to test.
	 */
	private function require_capability( $capability ) {
		if ( current_user_can( $capability ) ) {
			return;
		}

		wp_die(
			esc_html__( 'You do not have permission to perform this action.', 'dev-time-tracker' ),
			esc_html__( 'Permission denied', 'dev-time-tracker' ),
			array( 'response' => 403 )
		);
	}

	/**
	 * Start a new timed session.
	 */
	public function handle_start_timer() {
		check_admin_referer( 'dtt_start_timer_action' );
		$this->require_capability( self::CAP_TRACK );

		$user_id = get_current_user_id();

		if ( DTT_DB::get_active_session( $user_id ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=dev-time-tracker&dtt_error=already_tracking' ) );
			exit;
		}

		$task_title = isset( $_POST['task_title'] ) ? sanitize_text_field( wp_unslash( $_POST['task_title'] ) ) : '';

		if ( '' === $task_title && get_option( 'dtt_require_task', 1 ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=dev-time-tracker&dtt_error=task_required' ) );
			exit;
		}

		if ( '' === $task_title ) {
			$task_title = __( 'Untitled task', 'dev-time-tracker' );
		}

		$project_id = isset( $_POST['project_id'] ) ? sanitize_text_field( wp_unslash( $_POST['project_id'] ) ) : '';
		$tag_input  = isset( $_POST['tags'] ) ? sanitize_text_field( wp_unslash( $_POST['tags'] ) ) : '';
		$project    = DTT_Projects::get( $project_id );
		$tags       = DTT_Projects::sanitize_tag_list( $tag_input );

		$billable = ! empty( $_POST['billable'] ) ? 1 : 0;

		DTT_DB::insert_entry(
			array(
				'user_id'          => $user_id,
				'project_id'       => $project['id'],
				'project_name'     => $project['name'],
				'project_color'    => $project['color'],
				'task_title'       => $task_title,
				'tags'             => $tags,
				'start_time'       => current_time( 'mysql' ),
				'end_time'         => null,
				'duration_seconds' => 0,
				'billable'         => $billable,
				'hourly_rate'      => $project['rate'],
				'site_area'        => '',
			)
		);

		DTT_Audit::log_event(
			'timer_start',
			$project['name'],
			/* translators: %s: task description. */
			sprintf( __( 'Session started: %s', 'dev-time-tracker' ), $task_title )
		);

		wp_safe_redirect( admin_url( 'admin.php?page=dev-time-tracker&dtt_msg=timer_started' ) );
		exit;
	}

	/**
	 * Stop the current user's active session.
	 */
	public function handle_stop_timer() {
		check_admin_referer( 'dtt_stop_timer_action' );
		$this->require_capability( self::CAP_TRACK );

		$user_id = get_current_user_id();
		$session = DTT_DB::get_active_session( $user_id );

		if ( ! $session ) {
			wp_safe_redirect( admin_url( 'admin.php?page=dev-time-tracker&dtt_error=not_tracking' ) );
			exit;
		}

		$now      = current_time( 'mysql' );
		$duration = max( 1, strtotime( $now ) - strtotime( $session->start_time ) );

		DTT_DB::update_entry(
			$session->id,
			array(
				'end_time'         => $now,
				'duration_seconds' => $duration,
			)
		);

		DTT_Audit::log_event(
			'timer_stop',
			$session->project_name,
			/* translators: 1: task description, 2: number of minutes. */
			sprintf( __( 'Session ended: %1$s (%2$d minutes)', 'dev-time-tracker' ), $session->task_title, (int) round( $duration / MINUTE_IN_SECONDS ) )
		);

		$this->maybe_notify_session_end( $session, $duration );

		wp_safe_redirect( admin_url( 'admin.php?page=dev-time-tracker&dtt_msg=timer_stopped' ) );
		exit;
	}

	/**
	 * Email a session summary when the site owner has opted in.
	 *
	 * @param object $session  Session row.
	 * @param int    $duration Duration in seconds.
	 */
	private function maybe_notify_session_end( $session, $duration ) {
		if ( ! get_option( 'dtt_notify_logout', 0 ) ) {
			return;
		}

		$recipient = get_option( 'dtt_notify_email', '' );

		if ( ! is_email( $recipient ) ) {
			$recipient = get_option( 'admin_email' );
		}

		if ( ! is_email( $recipient ) ) {
			return;
		}

		$site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

		$subject = sprintf(
			/* translators: %s: site name. */
			__( '[%s] Development session completed', 'dev-time-tracker' ),
			$site_name
		);

		$lines = array(
			/* translators: %s: task description. */
			sprintf( __( 'Task: %s', 'dev-time-tracker' ), $session->task_title ),
			/* translators: %s: project name. */
			sprintf( __( 'Project: %s', 'dev-time-tracker' ), $session->project_name ),
			/* translators: %d: number of minutes. */
			sprintf( __( 'Duration: %d minutes', 'dev-time-tracker' ), (int) round( $duration / MINUTE_IN_SECONDS ) ),
			$session->billable
				? __( 'Billable: yes', 'dev-time-tracker' )
				: __( 'Billable: no', 'dev-time-tracker' ),
		);

		wp_mail( $recipient, $subject, implode( "\n", $lines ) );
	}

	/**
	 * Append a timestamped note to the running session.
	 */
	public function handle_add_milestone() {
		check_admin_referer( 'dtt_add_milestone_action' );
		$this->require_capability( self::CAP_TRACK );

		$user_id = get_current_user_id();
		$session = DTT_DB::get_active_session( $user_id );
		$note    = isset( $_POST['milestone_note'] ) ? sanitize_text_field( wp_unslash( $_POST['milestone_note'] ) ) : '';

		if ( $session && '' !== $note ) {
			$existing = $session->notes ? $session->notes . "\n" : '';
			$updated  = $existing . '[' . current_time( 'H:i' ) . '] ' . $note;

			DTT_DB::update_entry( $session->id, array( 'notes' => $updated ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=dev-time-tracker&dtt_msg=milestone_added' ) );
		exit;
	}

	/**
	 * Store a manually entered timesheet row.
	 */
	public function handle_add_entry() {
		check_admin_referer( 'dtt_add_entry_action' );
		$this->require_capability( self::CAP_TRACK );

		$user_id    = get_current_user_id();
		$task_title = isset( $_POST['task_title'] ) ? sanitize_text_field( wp_unslash( $_POST['task_title'] ) ) : '';

		if ( '' === $task_title ) {
			$task_title = __( 'Untitled task', 'dev-time-tracker' );
		}

		$project_id = isset( $_POST['project_id'] ) ? sanitize_text_field( wp_unslash( $_POST['project_id'] ) ) : '';
		$project    = DTT_Projects::get( $project_id );

		$hours    = isset( $_POST['hours'] ) ? max( 0, floatval( wp_unslash( $_POST['hours'] ) ) ) : 0;
		$minutes  = isset( $_POST['minutes'] ) ? max( 0, floatval( wp_unslash( $_POST['minutes'] ) ) ) : 0;
		$rate     = isset( $_POST['hourly_rate'] ) ? max( 0, floatval( wp_unslash( $_POST['hourly_rate'] ) ) ) : (float) $project['rate'];
		$billable = ! empty( $_POST['billable'] ) ? 1 : 0;
		$notes    = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';

		$duration = (int) round( ( $hours * HOUR_IN_SECONDS ) + ( $minutes * MINUTE_IN_SECONDS ) );

		if ( $duration < 1 ) {
			wp_safe_redirect( admin_url( 'admin.php?page=dtt-timesheets&dtt_error=invalid_duration' ) );
			exit;
		}

		$now = current_time( 'mysql' );

		DTT_DB::insert_entry(
			array(
				'user_id'          => $user_id,
				'project_id'       => $project['id'],
				'project_name'     => $project['name'],
				'project_color'    => $project['color'],
				'task_title'       => $task_title,
				'tags'             => '',
				'start_time'       => $now,
				'end_time'         => $now,
				'duration_seconds' => $duration,
				'billable'         => $billable,
				'hourly_rate'      => $rate,
				'notes'            => $notes,
				'site_area'        => '',
			)
		);

		wp_safe_redirect( admin_url( 'admin.php?page=dtt-timesheets&dtt_msg=entry_added' ) );
		exit;
	}

	/**
	 * Delete a timesheet entry.
	 */
	public function handle_delete_entry() {
		check_admin_referer( 'dtt_delete_entry_action' );
		$this->require_capability( self::CAP_TRACK );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified above.
		$id = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0;

		if ( $id < 1 ) {
			wp_safe_redirect( admin_url( 'admin.php?page=dtt-timesheets' ) );
			exit;
		}

		$entry = DTT_DB::get_entry( $id );

		if ( ! $entry ) {
			wp_safe_redirect( admin_url( 'admin.php?page=dtt-timesheets' ) );
			exit;
		}

		$is_own = (int) $entry->user_id === get_current_user_id();

		if ( ! $is_own && ! current_user_can( self::CAP_MANAGE ) ) {
			$this->require_capability( self::CAP_MANAGE );
		}

		DTT_DB::delete_entry( $id );

		wp_safe_redirect( admin_url( 'admin.php?page=dtt-timesheets&dtt_msg=entry_deleted' ) );
		exit;
	}

	/**
	 * Save the plugin settings.
	 */
	public function handle_save_settings() {
		check_admin_referer( 'dtt_save_settings_action' );
		$this->require_capability( self::CAP_MANAGE );

		update_option( 'dtt_auto_prompt', empty( $_POST['dtt_auto_prompt'] ) ? 0 : 1 );
		update_option( 'dtt_require_task', empty( $_POST['dtt_require_task'] ) ? 0 : 1 );
		update_option( 'dtt_default_billable', empty( $_POST['dtt_default_billable'] ) ? 0 : 1 );
		update_option( 'dtt_notify_logout', empty( $_POST['dtt_notify_logout'] ) ? 0 : 1 );
		update_option( 'dtt_audit_enabled', empty( $_POST['dtt_audit_enabled'] ) ? 0 : 1 );

		$idle_allowed = array( 0, 5, 10, 15, 30 );
		$idle         = isset( $_POST['dtt_idle_minutes'] ) ? absint( wp_unslash( $_POST['dtt_idle_minutes'] ) ) : 10;
		update_option( 'dtt_idle_minutes', in_array( $idle, $idle_allowed, true ) ? $idle : 10 );

		$retention_allowed = array( 0, 30, 90, 180, 365 );
		$retention         = isset( $_POST['dtt_audit_retention_days'] ) ? absint( wp_unslash( $_POST['dtt_audit_retention_days'] ) ) : 90;
		update_option( 'dtt_audit_retention_days', in_array( $retention, $retention_allowed, true ) ? $retention : 90 );

		$rate = isset( $_POST['dtt_default_rate'] ) ? max( 0, floatval( wp_unslash( $_POST['dtt_default_rate'] ) ) ) : 0;
		update_option( 'dtt_default_rate', $rate );

		$currency_choice = isset( $_POST['dtt_currency'] ) ? sanitize_text_field( wp_unslash( $_POST['dtt_currency'] ) ) : '$';

		if ( 'custom' === $currency_choice ) {
			$currency_choice = isset( $_POST['dtt_currency_custom'] ) ? sanitize_text_field( wp_unslash( $_POST['dtt_currency_custom'] ) ) : '';
		}

		update_option( 'dtt_currency', '' === $currency_choice ? '$' : $currency_choice );

		$email = isset( $_POST['dtt_notify_email'] ) ? sanitize_email( wp_unslash( $_POST['dtt_notify_email'] ) ) : '';
		update_option( 'dtt_notify_email', is_email( $email ) ? $email : '' );

		// Every scalar leaf is sanitized right here with map_deep(); DTT_Projects::save_from_request()
		// then re-validates each field's type, length and format before it is persisted.
		$raw_projects = isset( $_POST['dtt_projects'] ) && is_array( $_POST['dtt_projects'] )
			? map_deep( wp_unslash( $_POST['dtt_projects'] ), 'sanitize_text_field' )
			: array();

		$new_project = isset( $_POST['dtt_new_project'] ) && is_array( $_POST['dtt_new_project'] )
			? map_deep( wp_unslash( $_POST['dtt_new_project'] ), 'sanitize_text_field' )
			: array();

		DTT_Projects::save_from_request( $raw_projects, $new_project );

		wp_safe_redirect( admin_url( 'admin.php?page=dtt-settings&dtt_msg=settings_saved' ) );
		exit;
	}

	/**
	 * Stream a CSV export of timesheet entries.
	 */
	public function handle_export_csv() {
		check_admin_referer( 'dtt_export_csv_action' );
		$this->require_capability( self::CAP_TRACK );

		$scope_user = current_user_can( self::CAP_MANAGE ) ? 0 : get_current_user_id();
		$entries    = DTT_DB::get_entries(
			array(
				'user_id' => $scope_user,
				'limit'   => 5000,
			)
		);

		$rows = array(
			array(
				__( 'ID', 'dev-time-tracker' ),
				__( 'User', 'dev-time-tracker' ),
				__( 'Project', 'dev-time-tracker' ),
				__( 'Task', 'dev-time-tracker' ),
				__( 'Start', 'dev-time-tracker' ),
				__( 'Hours', 'dev-time-tracker' ),
				__( 'Rate', 'dev-time-tracker' ),
				__( 'Billable', 'dev-time-tracker' ),
				__( 'Total', 'dev-time-tracker' ),
			),
		);

		foreach ( $entries as $entry ) {
			$hours = round( $entry->duration_seconds / HOUR_IN_SECONDS, 2 );
			$total = $entry->billable ? round( $hours * (float) $entry->hourly_rate, 2 ) : 0;

			$rows[] = array(
				$entry->id,
				isset( $entry->display_name ) ? $entry->display_name : '',
				$entry->project_name,
				$entry->task_title,
				$entry->start_time,
				$hours,
				$entry->hourly_rate,
				$entry->billable ? __( 'Yes', 'dev-time-tracker' ) : __( 'No', 'dev-time-tracker' ),
				$total,
			);
		}

		$csv = '';

		foreach ( $rows as $row ) {
			$csv .= self::to_csv_line( $row );
		}

		$filename = 'dev-time-tracker-export-' . gmdate( 'Y-m-d' ) . '.csv';

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $csv ) );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSV download body, fields are escaped by to_csv_line().
		echo $csv;
		exit;
	}

	/**
	 * Build one CSV record, guarding against spreadsheet formula injection.
	 *
	 * @param array $fields Field values.
	 * @return string
	 */
	private static function to_csv_line( array $fields ) {
		$escaped = array();

		foreach ( $fields as $field ) {
			$value = (string) $field;

			if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
				$value = "'" . $value;
			}

			$escaped[] = '"' . str_replace( '"', '""', $value ) . '"';
		}

		return implode( ',', $escaped ) . "\r\n";
	}
}

register_activation_hook( __FILE__, array( 'DTT_DB', 'install_tables' ) );
register_deactivation_hook( __FILE__, array( 'DTT_DB', 'handle_deactivation' ) );

/**
 * Boot the plugin.
 *
 * @return Dev_Time_Tracker
 */
function devtime_tracker_init() {
	return Dev_Time_Tracker::instance();
}

devtime_tracker_init();
