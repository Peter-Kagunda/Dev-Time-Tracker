<?php
/**
 * Removes all plugin data on uninstall.
 *
 * @package DevTimeTracker
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Delete the tables and options for the current site.
 */
function dtt_uninstall_site() {
	global $wpdb;

	$tables = array(
		$wpdb->prefix . 'dtt_entries',
		$wpdb->prefix . 'dtt_audit',
	);

	foreach ( $tables as $table ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Removing this plugin's own custom tables on uninstall; no core API exists for this.
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $table ) );
	}

	$options = array(
		'dtt_db_version',
		'dtt_projects',
		'dtt_default_rate',
		'dtt_currency',
		'dtt_default_billable',
		'dtt_auto_prompt',
		'dtt_idle_minutes',
		'dtt_require_task',
		'dtt_notify_email',
		'dtt_notify_logout',
		'dtt_audit_enabled',
		'dtt_audit_retention_days',
		'dtt_track_git',
	);

	foreach ( $options as $option ) {
		delete_option( $option );
	}

	$timestamp = wp_next_scheduled( 'dtt_prune_audit_log' );

	if ( $timestamp ) {
		wp_unschedule_event( $timestamp, 'dtt_prune_audit_log' );
	}

	if ( function_exists( 'wp_cache_flush_group' ) ) {
		wp_cache_flush_group( 'dev_time_tracker' );
	}
}

if ( is_multisite() ) {
	$dtt_site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);

	foreach ( $dtt_site_ids as $dtt_site_id ) {
		switch_to_blog( $dtt_site_id );
		dtt_uninstall_site();
		restore_current_blog();
	}
} else {
	dtt_uninstall_site();
}
