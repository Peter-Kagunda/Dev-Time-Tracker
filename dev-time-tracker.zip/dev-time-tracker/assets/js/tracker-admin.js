/**
 * Dev Time Tracker admin behaviour.
 *
 * @package DevTimeTracker
 */

/* global jQuery, dttConfig */
( function ( $ ) {
	'use strict';

	var config = window.dttConfig || {};
	var strings = config.i18n || {};

	/**
	 * Format a number of seconds as HH:MM:SS.
	 *
	 * @param {number} totalSeconds Seconds elapsed.
	 * @return {string} Formatted clock value.
	 */
	function formatTime( totalSeconds ) {
		var hours = Math.floor( totalSeconds / 3600 );
		var minutes = Math.floor( ( totalSeconds % 3600 ) / 60 );
		var seconds = totalSeconds % 60;

		return [ hours, minutes, seconds ]
			.map( function ( part ) {
				return part < 10 ? '0' + part : String( part );
			} )
			.join( ':' );
	}

	/**
	 * Keep an element updated with the time elapsed since a start timestamp.
	 *
	 * @param {Object} $element Target element.
	 */
	function startTicker( $element ) {
		var start = parseInt( $element.attr( 'data-start' ) || '0', 10 );

		if ( ! start ) {
			return;
		}

		var tick = function () {
			var now = Math.floor( Date.now() / 1000 );
			$element.text( formatTime( Math.max( 0, now - start ) ) );
		};

		tick();
		window.setInterval( tick, 1000 );
	}

	$( function () {
		// Live counters on the plugin screen and in the admin bar.
		$( '#dtt-live-clock' ).each( function () {
			startTicker( $( this ) );
		} );

		$( '.dtt-ab-timer' ).each( function () {
			startTicker( $( this ) );
		} );

		// Billable toggle.
		$( '#dtt-btn-billable-toggle' ).on( 'click', function () {
			var $button = $( this );
			var $field = $( '#dtt-billable-hidden' );
			var isBillable = '1' === $field.val();

			if ( isBillable ) {
				$field.val( '0' );
				$button.addClass( 'free' ).attr( 'aria-pressed', 'false' );
				$button.find( 'span' ).text( $button.attr( 'data-label-free' ) );
			} else {
				$field.val( '1' );
				$button.removeClass( 'free' ).attr( 'aria-pressed', 'true' );
				$button.find( 'span' ).text( $button.attr( 'data-label-billable' ) );
			}
		} );

		// Manual entry panel.
		$( '#dtt-btn-open-manual' ).on( 'click', function () {
			var $button = $( this );
			var $panel = $( '#dtt-manual-entry-card' );
			var isHidden = $panel.prop( 'hidden' );

			$panel.prop( 'hidden', false );

			if ( isHidden ) {
				$panel.hide().slideDown( 200 );
				$button.attr( 'aria-expanded', 'true' );
			} else {
				$panel.slideUp( 200, function () {
					$panel.prop( 'hidden', true );
				} );
				$button.attr( 'aria-expanded', 'false' );
			}
		} );

		// Billing summary dialog.
		var $invoiceModal = $( '#dtt-invoice-modal' );

		$( '#dtt-btn-open-invoice' ).on( 'click', function () {
			$invoiceModal.css( 'display', 'flex' ).hide().fadeIn( 150 );
		} );

		$( '#dtt-btn-print' ).on( 'click', function () {
			window.print();
		} );

		$( '.dtt-modal-close' ).on( 'click', function () {
			$invoiceModal.fadeOut( 150 );
		} );

		$invoiceModal.on( 'click', function ( event ) {
			if ( $( event.target ).is( '#dtt-invoice-modal' ) ) {
				$invoiceModal.fadeOut( 150 );
			}
		} );

		$( document ).on( 'keydown', function ( event ) {
			if ( 'Escape' !== event.key ) {
				return;
			}

			if ( $invoiceModal.is( ':visible' ) ) {
				$invoiceModal.fadeOut( 150 );
			}

			$( '#dtt-login-modal' ).hide();
		} );

		// Clock-in prompt.
		$( '#dtt-login-modal-dismiss' ).on( 'click', function () {
			$( '#dtt-login-modal' ).hide();
		} );

		// Idle reminder while a session is running.
		var idleMinutes = parseInt( config.idleMinutes || 0, 10 );
		var $liveClock = $( '#dtt-live-clock' );

		if ( idleMinutes > 0 && $liveClock.length ) {
			var idleSeconds = 0;
			var maxIdle = idleMinutes * 60;
			var warned = false;

			$( document ).on( 'mousemove keydown scroll click', function () {
				idleSeconds = 0;
				warned = false;
			} );

			window.setInterval( function () {
				idleSeconds += 10;

				if ( idleSeconds >= maxIdle && ! warned ) {
					warned = true;

					if ( strings.idleNotice && window.wp && window.wp.a11y ) {
						window.wp.a11y.speak( strings.idleNotice );
					}

					$( '#dtt-idle-warning' )
						.html( $( '<p></p>' ).text( strings.idleNotice || '' ) )
						.prop( 'hidden', false );
				}
			}, 10000 );
		}

		// Currency settings: reveal the custom symbol field only when needed.
		$( '#dtt_currency' ).on( 'change', function () {
			$( '#dtt_currency_custom' ).prop( 'hidden', 'custom' !== $( this ).val() );
		} );
	} );
} )( jQuery );
